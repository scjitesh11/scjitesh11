# Databricks notebook source
# Load Bank Data from S3 path
csv_data_path = "/mnt/s3dataread/bank-customers.csv"
bank_df = spark.read.csv(csv_data_path, header=True, inferSchema=True)


# COMMAND ----------

delta_path = "/mnt/s3dataread/output-bank-customers/delta"

# Load processed data from Delta Lake
validated_df = spark.read.format("delta").load(delta_path)

# Check for null values in critical columns
critical_columns = ["balance", "job"]

# Calculate the count of rows with nulls in critical columns
null_counts = {col: validated_df.filter(validated_df[col].isNull()).count() for col in critical_columns}

# Print validation summary
for col, count in null_counts.items():
    print(f"Column {col} has {count} null values")

# Raise an alert if any critical column has nulls
if any(count > 0 for count in null_counts.values()):
    print("Validation failed: critical columns contain null values.")
else:
    print("Validation passed: No null values found in critical columns.")

# COMMAND ----------

