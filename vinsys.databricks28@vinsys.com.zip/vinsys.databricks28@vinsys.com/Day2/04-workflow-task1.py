# Databricks notebook source
# Load Bank Data from S3 path
csv_data_path = "/mnt/s3dataread/bank-customers.csv"
bank_df = spark.read.csv(csv_data_path, header=True, inferSchema=True)

# Display a sample of the data
bank_df.show(5)