# Databricks notebook source
# MAGIC %md
# MAGIC # Reading and Writing Data from S3, Redshift, and Oracle DB
# MAGIC
# MAGIC This notebook demonstrates how to read from and write to multiple data sources in Databricks, including Amazon S3, Amazon Redshift, and Oracle DB. Each section covers the configuration, connection, and example code for data operations.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Introduction
# MAGIC
# MAGIC Databricks supports seamless connectivity with various data sources. In this notebook, we will:
# MAGIC - Connect to and access data stored in **AWS S3**.
# MAGIC - Perform read and write operations with **Amazon Redshift**.
# MAGIC - Access **Oracle DB** using JDBC for data ingestion and processing.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Reading and Writing Data with S3
# MAGIC
# MAGIC Amazon S3 is a widely used object storage service. We will demonstrate reading data from and writing data to an S3 bucket using Spark.
# MAGIC
# MAGIC **Prerequisites:**
# MAGIC - Set up an S3 bucket for data storage.
# MAGIC - Ensure Databricks has appropriate IAM permissions to access S3.

# COMMAND ----------

# Define S3 bucket and file paths
mount_name = 's3dataread'
s3_input_path = f'/mnt/{mount_name}/bank-customers.csv'
s3_output_path = f'/mnt/{mount_name}/output-data-bank-customers/csv/'

print('S3 paths configured.')

# COMMAND ----------

# Example: Reading data from S3
df_s3 = spark.read.csv(s3_input_path, header=True, inferSchema=True)
df_s3.show(5)

# COMMAND ----------

# Example: Writing data to S3
df_s3.write.csv(s3_output_path, header=True, mode='overwrite')
print('Data written to S3.')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Reading and Writing Data with Amazon Redshift
# MAGIC
# MAGIC Amazon Redshift is a managed data warehouse service. Using JDBC, we can read data from and write data to Redshift tables.
# MAGIC
# MAGIC **Steps to configure Redshift connection:**
# MAGIC 1. Set up a Redshift cluster.
# MAGIC 2. Ensure Databricks can access Redshift (using VPC peering or allowing IPs in security groups).
# MAGIC 3. Obtain JDBC URL and credentials.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Install JDBC Driver:
# MAGIC
# MAGIC  - You need to install the Redshift JDBC Driver in your Databricks cluster.
# MAGIC  - Use Maven to install the JDBC driver in Databricks:
# MAGIC ```
# MAGIC com.amazon.redshift:redshift-jdbc42:2.0.0.4
# MAGIC ```

# COMMAND ----------

table_name="bank_customers"

# COMMAND ----------

# MAGIC %scala
# MAGIC Class.forName("com.amazon.redshift.jdbc42.Driver")

# COMMAND ----------

redshift_url = 'jdbc:redshift://default-workgroup.135808924199.us-west-2.redshift-serverless.amazonaws.com:5439/dev'
redshift_properties = {
    'user': 'admin',
    'password': 'Xd193Cr99Po15'
}

# Ensure redshift_properties includes tcpKeepAlive and TCPKeepAliveMinutes
redshift_properties["driver"] = "com.amazon.redshift.jdbc42.Driver"
redshift_properties["tcpKeepAlive"] = "true"
redshift_properties["TCPKeepAliveMinutes"] = "1"

# Writing data to Redshift with the updated properties
df_s3.write \
    .format("jdbc") \
    .option("url", redshift_url) \
    .option("dbtable", table_name) \
    .option("mode", "append") \
    .options(**redshift_properties) \
    .save()

print('Data written to Redshift.')

# COMMAND ----------

# Example: Reading data from Redshift
table_name = 'bank_customers'
df_redshift = spark.read.jdbc(url=redshift_url, table=table_name, properties=redshift_properties)
df_redshift.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Reading and Writing Data with Oracle DB
# MAGIC
# MAGIC Oracle Database is a popular relational database management system. Using the Oracle JDBC driver, we can read and write data from Oracle DB.
# MAGIC
# MAGIC **Steps to configure Oracle DB connection:**
# MAGIC 1. Install Oracle JDBC driver on Databricks
# MAGIC 2. Define JDBC URL and connection properties.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Install Oracle JDBC Driver via Maven
# MAGIC  - Go to the Databricks workspace.
# MAGIC  - Navigate to the cluster that you want to use.
# MAGIC  - Click on the "Libraries" tab in the cluster page.
# MAGIC  - Click on "Install New" and select "Maven".
# MAGIC  - Enter the Maven coordinates for the Oracle JDBC driver.
# MAGIC  - For the ojdbc8.jar (which is compatible with Java 8 and later), use the following Maven coordinates:
# MAGIC
# MAGIC ```
# MAGIC com.oracle.database.jdbc:ojdbc8:19.8.0.0
# MAGIC ```

# COMMAND ----------

# Define Oracle DB connection parameters

oracle_url = "jdbc:oracle:thin:@database-oracle.c3q0aceg8b09.us-west-2.rds.amazonaws.com:1521/ORCL"

oracle_properties = {
    'user': 'admin',
    'password': 'Xd19Nm03Cr99Po15$!#V1',
    'driver': 'oracle.jdbc.driver.OracleDriver'
}

print('Oracle DB connection configured.')

# Example: Reading data from Oracle DB
oracle_table_name = 'bank_customers'

# Example: Writing data to Oracle DB
df_s3.write.jdbc(
    url=oracle_url,
    table=oracle_table_name,
    mode='append',
    properties=oracle_properties
)
print('Data written to Oracle DB.')

# COMMAND ----------

df_oracle = spark.read.jdbc(url=oracle_url, table=oracle_table_name, properties=oracle_properties)
df_oracle.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Best Practices for Multi-Source Data Management
# MAGIC
# MAGIC When working with multiple data sources, consider these best practices:
# MAGIC - **Security**: Use IAM roles and secure credentials management (e.g., AWS Secrets Manager).
# MAGIC - **Performance**: Use partitioned reads and writes for large datasets.
# MAGIC - **Error Handling**: Implement error handling and retries for network issues or timeouts.
# MAGIC
# MAGIC These practices help ensure reliable data ingestion and processing across different data sources.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC
# MAGIC In this notebook, we demonstrated how to read from and write to Amazon S3, Redshift, and Oracle DB in Databricks. We configured connections, explored data operations, and discussed best practices for working with multiple data sources in a reliable and secure manner.
# MAGIC