# Databricks notebook source
# MAGIC %md
# MAGIC # Connecting and Managing Data in AWS RDS
# MAGIC
# MAGIC This notebook provides a guide for connecting Databricks to AWS RDS, including steps for configuring access, reading and writing data, and best practices for managing structured data in RDS.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Introduction to AWS RDS in Databricks
# MAGIC
# MAGIC Amazon RDS (Relational Database Service) is a managed relational database service that supports multiple database engines such as MySQL, PostgreSQL, and SQL Server. RDS enables Databricks to work with structured data stored in relational databases for applications like analytics and reporting.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Setting Up AWS RDS and Preparing Data
# MAGIC
# MAGIC Follow these steps to create an RDS instance and prepare it for Databricks access:
# MAGIC
# MAGIC **Steps:**
# MAGIC 1. **Create an RDS Instance**:
# MAGIC    - Go to the [AWS RDS Console](https://aws.amazon.com/rds/).
# MAGIC    - Click 'Create database'.
# MAGIC    - Choose a database engine - PostgreSQL
# MAGIC    - Configure database instance settings, including name, credentials, and storage.
# MAGIC
# MAGIC 2. **Prepare the Database**:
# MAGIC    - Connect to the RDS instance using a client like MySQL Workbench or pgAdmin.
# MAGIC    - Create a new schema and tables if needed, and load sample data.
# MAGIC    - Sample data can be uploaded via SQL scripts or imported from local files.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Configuring Access and Permissions
# MAGIC
# MAGIC To allow Databricks to connect securely to RDS, configure IAM roles and network settings:
# MAGIC
# MAGIC **Steps:**
# MAGIC 1. **Security Group for RDS**:
# MAGIC    - Create or modify the RDS security group to allow inbound traffic from Databricks IP ranges.
# MAGIC    - Open port 5432 for PostgreSQL or 3306 for MySQL.
# MAGIC
# MAGIC 2. **Create IAM Role with RDS Access (if using IAM Authentication)**:
# MAGIC    - Go to the [IAM Console](https://console.aws.amazon.com/iam/).
# MAGIC    - Create a role and attach the `AmazonRDSFullAccess` policy.
# MAGIC    - Attach this IAM role to your Databricks cluster for secure access.

# COMMAND ----------

# Define variables for RDS connection details
rds_endpoint = 'database-1.c3q0aceg8b09.us-west-2.rds.amazonaws.com'
database_name = 'postgres'
table_name = 'bank_customers'
user = 'postgres'
password = 'RriuGSo6XPrDUPZ5Xyeh'
jdbc_url = f'jdbc:postgresql://{rds_endpoint}:5432/{database_name}'
print('RDS connection variables configured.')

# COMMAND ----------

properties = {
    'user': user,
    'password': password,
    'driver': 'org.postgresql.Driver'  # Adjust for your RDS database type
}

# COMMAND ----------

# Define variables for S3 bucket and paths
mount_name = 's3dataread'
csv_data_path = f'/mnt/{mount_name}/bank-customers.csv'

# COMMAND ----------

# Example: Reading CSV Data from S3
df_csv = spark.read.csv(csv_data_path, header=True, inferSchema=True)
df_csv.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Writing Data to RDS
# MAGIC
# MAGIC We can also write data from Databricks back to RDS tables for storage. This example demonstrates writing a Spark DataFrame to an RDS table.

# COMMAND ----------

# MAGIC %scala
# MAGIC Class.forName("org.postgresql.Driver")

# COMMAND ----------

jdbc_url = f'jdbc:postgresql://{rds_endpoint}:5432/{database_name}'

# COMMAND ----------

# Example: Writing Data to RDS
df_csv.write.jdbc(url=jdbc_url, table=table_name, mode='append', properties=properties)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Reading Data from RDS
# MAGIC
# MAGIC With access configured, we can use the JDBC URL to connect and read data from RDS. This section demonstrates how to query an RDS table into a Spark DataFrame.

# COMMAND ----------

# Example: Reading Data from RDS


df_rds = spark.read.jdbc(url=jdbc_url, table=table_name, properties=properties)
display(df_rds)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Best Practices for Managing RDS Data
# MAGIC
# MAGIC Consider the following best practices for efficiently managing data in RDS:
# MAGIC - **Indexing**: Ensure that tables have appropriate indexes to speed up queries.
# MAGIC - **Connection Pooling**: Limit connections to avoid overloading the database.
# MAGIC - **Data Archiving**: Periodically archive old data to manage storage costs.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC
# MAGIC In this notebook, we covered the steps to connect and manage data in AWS RDS from Databricks, including configuring access, reading and writing data, and best practices for relational database management. This setup enables structured data processing for analytics and reporting.
# MAGIC
# MAGIC

# COMMAND ----------

