# Databricks notebook source
# MAGIC %md
# MAGIC # Connecting and Managing Data in AWS S3
# MAGIC
# MAGIC This notebook provides a guide for connecting Databricks to AWS S3, including steps for configuring access, reading and writing data, and best practices for managing data storage.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Introduction to AWS S3 in Databricks
# MAGIC
# MAGIC Amazon S3 (Simple Storage Service) is an object storage service that provides scalable and durable storage for large datasets. In this notebook, we demonstrate how to set up S3 for storing and accessing data with Databricks, enabling efficient data processing.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Setting Up AWS S3 and Uploading Data
# MAGIC
# MAGIC To begin, follow these steps to create an S3 bucket, set permissions, and upload data.
# MAGIC
# MAGIC **Steps:**
# MAGIC 1. **Create an S3 Bucket**:
# MAGIC    - Go to the [AWS S3 Console](https://s3.console.aws.amazon.com/s3).
# MAGIC    - Click 'Create bucket'.
# MAGIC    - Enter a unique bucket name and select a region.
# MAGIC    - Leave default settings for other configurations and click 'Create bucket'.
# MAGIC
# MAGIC 2. **Upload Sample Data**:
# MAGIC    - Inside your new bucket, click 'Upload' to add sample files.
# MAGIC    - Prepare CSV or Parquet files locally for testing, or download sample data from sites like [Kaggle](https://www.kaggle.com/).
# MAGIC    - Select the files and upload them to the S3 bucket.
# MAGIC

# COMMAND ----------

access_key = 'AKIAR7HWXXIT7JWKOLSA'
secret_key = 'anARNsfgNuga4uyFe0TLwvO9GpmUVqPzLpq8F3/9'
encoded_secret_key = secret_key.replace("/", "%2F")

# COMMAND ----------

# Define variables for S3 bucket and paths
bucket_name = 'bktagdbnov242'
mount_name = 's3dataread'
csv_data_path = f'/mnt/{mount_name}/bank-customers.csv'
output_csv_path = f'/mnt/{mount_name}/output-data-bank-customers/csv/'
output_parquet_path = f'/mnt/{mount_name}/output-bank-customers/parquet/'

print(f"csv_data_path: {csv_data_path}")
print(f"output_csv_path: {output_csv_path}")
print(f"output_parquet_path: {output_parquet_path}")

print('S3 paths configured.')

# COMMAND ----------

try:
  dbutils.fs.unmount(f'/mnt/{mount_name}')
except:
  pass

# COMMAND ----------

dbutils.fs.mount(f"s3a://{access_key}:{encoded_secret_key}@{bucket_name}", f"/mnt/{mount_name}")

# COMMAND ----------

# MAGIC %fs ls /mnt/s3dataread

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Reading Data from S3
# MAGIC
# MAGIC Once access is set up, we can read data from S3 using Spark. This section covers reading data in CSV and Parquet formats from an S3 bucket into a Spark DataFrame.

# COMMAND ----------

# Example: Reading CSV Data from S3
df_csv = spark.read.csv(csv_data_path, header=True, inferSchema=True)
df_csv.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Writing Data to S3
# MAGIC
# MAGIC In addition to reading data, we can also write processed data back to S3. We will cover writing data in CSV and Parquet formats, with options for partitioning.

# COMMAND ----------

# Example: Writing Data to S3 as CSV
df_csv.write.csv(output_csv_path, header=True, mode='overwrite')


# COMMAND ----------

# Example: Writing Data to S3 as CSV
output_csv_path = ""
df_csv.write.parquet(output_parquet_path, mode='overwrite')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Managing Data in S3
# MAGIC
# MAGIC For efficient data management in S3, consider the following best practices:
# MAGIC - **Partitioning**: Use partitioned data storage to improve query performance.
# MAGIC - **Organized Folder Structure**: Use a structured path format (e.g., `/year=2023/month=01/day=01`).
# MAGIC - **Versioning**: Enable versioning on S3 buckets for data recovery.
# MAGIC
# MAGIC These practices help optimize storage and make data retrieval more efficient.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC
# MAGIC In this notebook, we covered the steps to connect and manage data in AWS S3 from Databricks, including configuring access, reading and writing data, and best practices for S3 storage management. This knowledge is fundamental for handling large datasets in a scalable environment.
# MAGIC
# MAGIC