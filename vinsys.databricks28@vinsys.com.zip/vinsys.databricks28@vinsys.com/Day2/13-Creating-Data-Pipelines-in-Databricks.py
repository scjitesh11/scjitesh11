# Databricks notebook source
# MAGIC %md
# MAGIC # Guide to Creating Data Pipelines in Databricks

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Introduction to Data Pipelines in Databricks
# MAGIC
# MAGIC A **data pipeline** is an automated process that ingests, processes, and stores data for downstream analytics and machine learning. Databricks offers a powerful ecosystem to design and run scalable pipelines, leveraging Apache Spark and Delta Lake for reliable, fast data handling.
# MAGIC
# MAGIC ### Benefits of Using Databricks for Data Pipelines:
# MAGIC - **Scalability**: Databricks scales with your data and workload, handling massive data volumes efficiently.
# MAGIC - **Delta Lake**: Provides data reliability with ACID transactions, time-travel, and schema evolution.
# MAGIC - **Auto Loader**: Enables efficient, incremental, and real-time data ingestion.
# MAGIC - **Delta Live Tables (DLT)**: Simplifies the creation of reliable and manageable ETL pipelines.
# MAGIC - **Job Scheduling**: Automates pipeline execution for continuous data processing.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Key Components for Data Pipelines
# MAGIC
# MAGIC 1. **Delta Lake**: Provides a storage layer with ACID transactions, schema enforcement, and time-travel.
# MAGIC 2. **Auto Loader**: Enables efficient and real-time data ingestion from cloud storage.
# MAGIC 3. **Delta Live Tables (DLT)**: Manages data transformations with declarative definitions and data quality checks.
# MAGIC 4. **Databricks Jobs**: Automates and schedules pipeline tasks.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 3. Step-by-Step Guide to Creating a Data Pipeline
# MAGIC
# MAGIC ### Step 1: Data Ingestion with Auto Loader
# MAGIC
# MAGIC Auto Loader allows you to ingest data efficiently from sources such as S3, ADLS, or GCS. For this example, let’s assume retail data is in a mounted S3 path (`/mnt/s3dataread/retail-data/`).

# COMMAND ----------

# Define source path and checkpoint for Auto Loader
source_path = "/mnt/s3dataread/retail-data/by-day/test-auto-loaded/"
checkpoint_path = "dbfs:/checkpoints/retail_data_pipeline/"

# Ingest data with Auto Loader in CSV format
raw_data_df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "csv") 
    .option("header", "true")
    .option("cloudFiles.schemaLocation", checkpoint_path)  # Required for schema tracking
    .load(source_path)
)

# Display schema and data
raw_data_df.printSchema()
raw_data_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Data Transformation and Cleansing
# MAGIC
# MAGIC Perform data transformation to clean and standardize the data, including handling nulls, casting data types, and creating calculated columns.

# COMMAND ----------

from pyspark.sql.functions import col, to_date

# Clean and transform data
transformed_df = (
    raw_data_df
    .dropna(subset=["CustomerID", "Description", "Quantity", "UnitPrice"])  # Drop rows with critical nulls
    .withColumn("TotalValue", col("Quantity") * col("UnitPrice"))  # Add calculated column
    .withColumn("InvoiceDate", to_date("InvoiceDate", "yyyy-MM-dd HH:mm:ss"))  # Format date column
)

# Display transformed data
transformed_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Data Aggregation and Enrichment
# MAGIC
# MAGIC Aggregate data to create summary insights, such as total sales per customer or total sales by country.

# COMMAND ----------

# Aggregate data by customer to calculate total transaction amount
customer_aggregates_df = (
    transformed_df.groupBy("CustomerID")
    .agg({"TotalValue": "sum"})
    .withColumnRenamed("sum(TotalValue)", "TotalTransactionValue")
)

# Display aggregated data
customer_aggregates_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Writing Data to Delta Lake
# MAGIC
# MAGIC Write the final transformed and aggregated data to Delta Lake, which provides schema enforcement, ACID transactions, and versioned storage.

# COMMAND ----------

# Define Delta Lake path for the final data
delta_table_path = "/mnt/s3dataread/delta/retail_aggregates/"

print(customer_aggregates_df)

# Write transformed data to Delta Lake
customer_aggregates_df.writeStream.format("delta") \
    .outputMode("Complete") \
    .partitionBy("CustomerID") \
    .option("checkpointLocation", "/mnt/s3dataread/delta/retail_aggregates/_checkpoints/") \
    .start(delta_table_path)

print("Data successfully written to Delta Lake.")