# Databricks notebook source
# Load Bank Data from S3 path
csv_data_path = "/mnt/s3dataread/bank-customers.csv"
bank_df = spark.read.csv(csv_data_path, header=True, inferSchema=True)


# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# Add a processing timestamp column
processed_bank_df = bank_df.withColumn("processed_timestamp", current_timestamp())

# Define Delta Lake path
delta_path = "/mnt/s3dataread/output-bank-customers/delta"

# Write to Delta Lake with overwrite mode and enable schema evolution
processed_bank_df.write.format("delta") \
    .option("mergeSchema", "true") \
    .mode("overwrite") \
    .save(delta_path)

# Display a message indicating successful transformation
print("Data has been transformed and written to Delta Lake.")