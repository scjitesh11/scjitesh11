# Databricks notebook source
# MAGIC %md
# MAGIC # Auto Loader for Efficient Data Ingestion with Mounted S3 Path

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Introduction to Auto Loader
# MAGIC
# MAGIC **Databricks Auto Loader** is an efficient and scalable tool for ingesting data from cloud object storage in both streaming and batch modes. It can automatically detect new or modified files and incrementally load them, making it ideal for building reliable, efficient data pipelines.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Setup and Prerequisites
# MAGIC
# MAGIC 1. **Databricks Workspace**: Ensure you have a Databricks workspace with Auto Loader enabled.
# MAGIC 2. **Mounted S3 Bucket**: Your retail data is mounted in Databricks, for example, at `/mnt/s3dataread/retail-data/`.
# MAGIC 3. **Permissions**: Ensure Databricks has the necessary permissions to read from this mount path.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 3. Reading Retail Data Using Auto Loader
# MAGIC
# MAGIC Now, let’s configure Auto Loader to read retail data from the mounted S3 path.
# MAGIC
# MAGIC ### Example 1: Basic CSV Ingestion with Auto Loader
# MAGIC
# MAGIC Use Auto Loader to ingest CSV files from your mounted path (`/mnt/s3dataread/retail-data/`).

# COMMAND ----------

# Define the mounted path to retail data
source_path = "/mnt/s3dataread/retail-data/by-day/test-auto-loaded/"

# Define a path for schema location
schema_location_path = "/mnt/s3dataread/retail-data-schema2/"

# Use Auto Loader to read data from the mounted S3 path in CSV format
retail_df = (
    spark.readStream.format("cloudFiles")  # Use Auto Loader
    .option("cloudFiles.format", "csv")    # Specify file format
    .option("header", "true")              # CSV header
    .option("cloudFiles.inferColumnTypes", "true")  # Enable schema inference
    .option("cloudFiles.schemaLocation", schema_location_path)  # Schema location for evolution
    .load(source_path)
)

# Display the schema and sample data
retail_df.printSchema()
display(retail_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 4. Auto Loader with Incremental Loading
# MAGIC
# MAGIC Auto Loader is designed to incrementally load only new or modified files, making it efficient for streaming ingestion. We’ll use a **checkpoint location** to track processed files.
# MAGIC
# MAGIC ### Example: Using Incremental Load Options
# MAGIC
# MAGIC Set up Auto Loader to incrementally ingest only new files from the mounted path.

# COMMAND ----------

# Define the checkpoint path for incremental loading
checkpoint_path = "dbfs:/checkpoints/retail_data2/"
target_path = "/mnt/s3dataread/retail-data/by-day/test-auto-loaded/"

# Configure Auto Loader for incremental loading from the mounted S3 path
incremental_df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .option("cloudFiles.schemaLocation", checkpoint_path)  # Required for incremental loading
    .option("cloudFiles.includeExistingFiles", "true")     # Process existing files initially
    .load(target_path)
)

# Write incremental data to a Delta Lake table
incremental_df.writeStream.format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", checkpoint_path) \
    .table("delta_incremental_retail_data")

# COMMAND ----------

# MAGIC %md
# MAGIC **Explanation**:
# MAGIC - **`cloudFiles.schemaLocation`**: Keeps track of the schema across streaming batches, required for incremental loading.
# MAGIC - **`cloudFiles.includeExistingFiles`**: Ensures that existing files in the directory are processed initially.
# MAGIC
# MAGIC ---
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## 6. Using Auto Loader for Real-Time Streaming
# MAGIC
# MAGIC Auto Loader can be configured for real-time ingestion, continuously listening for new files and loading them into Delta Lake.
# MAGIC
# MAGIC ### Example: Real-Time Data Ingestion with Auto Loader
# MAGIC
# MAGIC Set up real-time ingestion with Auto Loader to continuously process incoming files in `/mnt/s3dataread/retail-data/`.

# COMMAND ----------

# Define the checkpoint path for real-time streaming
realtime_checkpoint_path = "dbfs:/checkpoints/realtime_stream2/"

# Configure Auto Loader for real-time ingestion from the mounted path
realtime_df = (
    spark.readStream.format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .option("cloudFiles.schemaLocation", realtime_checkpoint_path)  # Required for schema tracking
    .load("/mnt/s3dataread/retail-data/by-day/test-auto-loaded/")
)

# Write streaming data to Delta Lake
realtime_df.writeStream.format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", realtime_checkpoint_path) \
    .table("realtime_retail_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 7. Monitoring and Optimizing Auto Loader
# MAGIC
# MAGIC ### Monitoring Auto Loader Jobs
# MAGIC

# COMMAND ----------

# Check the status and progress of the streaming query
streaming_query = realtime_df.writeStream.format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", realtime_checkpoint_path) \
    .table("realtime_retail_data")

# Display streaming query progress
display(streaming_query.lastProgress)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Optimizing with Partitioning
# MAGIC
# MAGIC Optimize storage and query performance by partitioning Delta tables based on commonly queried columns (e.g., `Country` or `InvoiceDate`).

# COMMAND ----------

# Partition by a column (e.g., InvoiceDate) for efficient storage and querying
incremental_df.writeStream.format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", checkpoint_path) \
    .partitionBy("InvoiceDate") \
    .table("partitioned_retail_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Summary
# MAGIC
# MAGIC In this guide, we demonstrated how to use **Databricks Auto Loader** to ingest data from a **mounted S3 bucket path** (`/mnt/s3dataread/retail-data/`) with:
# MAGIC 1. **Basic CSV Ingestion**: Ingesting CSV files from the mounted path.
# MAGIC 2. **Incremental Loading**: Configuring Auto Loader to load only new files incrementally.
# MAGIC 3. **Real-Time Ingestion**: Continuously processing new files as they arrive in the mounted path.