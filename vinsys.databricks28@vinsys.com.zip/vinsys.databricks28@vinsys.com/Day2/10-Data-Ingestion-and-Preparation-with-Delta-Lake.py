# Databricks notebook source
# MAGIC %md
# MAGIC # Data Ingestion and Preparation with Delta Lake on Databricks Using Retail Data
# MAGIC
# MAGIC This guide demonstrates the following:
# MAGIC 1. **Reading Retail Data from S3**
# MAGIC 2. **Preparing and Transforming Data for Analytics**
# MAGIC 3. **Writing Prepared Data to Delta Lake**
# MAGIC 4. **Optimizing Delta Lake Tables for Performance**
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Prerequisites
# MAGIC
# MAGIC - **S3 Bucket**: Retail data stored in S3 (e.g., `retail-data/2010-12-01.csv`).
# MAGIC - **Delta Lake Path**: A storage path in Databricks for Delta tables (e.g., `/mnt/delta/retail_data`).
# MAGIC - **Databricks Cluster**: Ensure Delta Lake is configured on your cluster.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 1: Read Retail Data from S3
# MAGIC
# MAGIC Define the S3 path and read data into a Spark DataFrame.

# COMMAND ----------

# Define S3 path to retail data
# Define S3 bucket and file paths
mount_name = 's3dataread'
s3_data_path = f'/mnt/{mount_name}/retail-data/all/online-retail-dataset.csv'
delta_table_path = f'/mnt/{mount_name}/retail-data/delta/online-retail-dataset'

# COMMAND ----------

# Read retail data from S3 into a DataFrame
try:
    retail_df = spark.read.csv(s3_data_path, header=True, inferSchema=True)
    print("Data successfully read from S3:")
    retail_df.show(5)
except Exception as e:
    print(f"Error reading data from S3: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sample Data Schema
# MAGIC The retail data might contain columns such as:
# MAGIC - `InvoiceNo`: Unique invoice identifier
# MAGIC - `StockCode`: Product code
# MAGIC - `Description`: Product description
# MAGIC - `Quantity`: Number of items
# MAGIC - `InvoiceDate`: Date and time of invoice
# MAGIC - `UnitPrice`: Price per item
# MAGIC - `CustomerID`: Unique customer identifier
# MAGIC - `Country`: Customer's country
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Step 2: Data Preparation and Cleaning
# MAGIC
# MAGIC ### Step 2.1 Handle Missing Values
# MAGIC
# MAGIC Remove rows with missing values in critical columns (`CustomerID`, `Description`, `Quantity`, and `UnitPrice`) to maintain data quality.

# COMMAND ----------

# Drop rows with nulls in critical columns
cleaned_df = retail_df.dropna(subset=["CustomerID", "Description", "Quantity", "UnitPrice"])

# Display cleaned data
print("Data after removing rows with missing values:")
cleaned_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2.2 Deduplicate Data
# MAGIC
# MAGIC Remove duplicate rows based on unique identifiers (e.g., `InvoiceNo` and `StockCode`) to avoid duplicate records in the analysis.

# COMMAND ----------

# Remove duplicate rows based on InvoiceNo and StockCode
deduped_df = cleaned_df.dropDuplicates(["InvoiceNo", "StockCode"])

print("Data after deduplication:")
deduped_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2.3 Enrichment: Add Calculated Columns
# MAGIC
# MAGIC Add a `TotalValue` column, which calculates the total value per line item (`Quantity * UnitPrice`), and convert `InvoiceDate` to a date format.

# COMMAND ----------

from pyspark.sql.functions import col, to_date

# Add TotalValue column and format InvoiceDate
transformed_df = (
    deduped_df
    .withColumn("TotalValue", col("Quantity") * col("UnitPrice"))
    .withColumn("InvoiceDate", to_date("InvoiceDate", "yyyy-MM-dd HH:mm:ss"))
)

print("Data after adding calculated columns:")
transformed_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Step 3: Writing Data to Delta Lake
# MAGIC
# MAGIC Delta Lake allows us to store data reliably with schema enforcement and optimizations. Use the Delta format to store the cleaned and enriched data in Delta Lake.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3.1 Write Data to Delta Lake with Schema Enforcement
# MAGIC
# MAGIC Write the transformed data into Delta Lake, enabling partitioning by `Country` for improved query performance.

# COMMAND ----------

# Write data to Delta Lake with schema enforcement and partitioning
try:
    transformed_df.write \
        .format("delta") \
        .mode("overwrite") \
        .partitionBy("Country") \
        .save(delta_table_path)
    print("Data successfully written to Delta Lake.")
except Exception as e:
    print(f"Error writing data to Delta Lake: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3.2 Verify Data in Delta Lake
# MAGIC
# MAGIC Read the data back from Delta Lake to verify that it has been written correctly.

# COMMAND ----------

# Read data from Delta Lake for verification
delta_df = spark.read.format("delta").load(delta_table_path)
print("Data successfully read from Delta Lake:")
delta_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Step 4: Optimizing Delta Lake Tables
# MAGIC
# MAGIC Delta Lake offers optimizations such as **Data Compaction** and **Z-Ordering** to improve query performance.
# MAGIC
# MAGIC ### 4.1 Data Compaction
# MAGIC
# MAGIC Compaction merges small files into larger files, which reduces the number of files in the Delta table and improves query speed.

# COMMAND ----------

from delta.tables import DeltaTable

# Compact Delta Lake table by merging small files
delta_table = DeltaTable.forPath(spark, delta_table_path)
delta_table.optimize().executeCompaction()

print("Data compaction completed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4.2 Z-Ordering
# MAGIC
# MAGIC Z-Ordering optimizes the data layout by sorting files based on specified columns, enhancing query performance for frequently filtered columns.

# COMMAND ----------

# Apply Z-Ordering on CustomerID to optimize queries that filter by customer
delta_table.optimize().executeZOrderBy("CustomerID")

print("Z-Ordering on CustomerID completed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4.3 Time Travel and Auditing
# MAGIC
# MAGIC Delta Lake’s **Time Travel** feature allows you to query historical data versions, making it easy to access past snapshots of the data.
# MAGIC
# MAGIC #### View Delta Table History
# MAGIC
# MAGIC Check the history of operations performed on the Delta table.

# COMMAND ----------

# View the history of the Delta table
delta_table.history().show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Query a Specific Version
# MAGIC
# MAGIC Query a specific version of the data for historical analysis.

# COMMAND ----------

# Query an older version of the data (e.g., version 0)
old_version_df = spark.read.format("delta").option("versionAsOf", 0).load(delta_table_path)
old_version_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Summary
# MAGIC
# MAGIC In this guide, we walked through the steps to **Ingest and Prepare Retail Data with Delta Lake on Databricks**. Here’s a summary of each step:
# MAGIC
# MAGIC 1. **Read Data from S3**: Loaded retail data from S3 into Databricks as a Spark DataFrame.
# MAGIC 2. **Data Preparation and Cleaning**: Removed null values, deduplicated records, and added calculated columns.
# MAGIC 3. **Write Data to Delta Lake**: Stored the data in Delta Lake with schema enforcement and partitioning.
# MAGIC 4. **Optimize Delta Lake Tables**: Applied data compaction and Z-ordering for improved query performance.
# MAGIC 5. **Time Travel**: Used Delta Lake’s time travel feature to query historical data versions.