# Databricks notebook source
# MAGIC %md
# MAGIC # Workflow Management in Databricks
# MAGIC
# MAGIC This notebook demonstrates how to manage workflows in Databricks, including creating, scheduling, and managing tasks with dependencies. The notebook uses your provided S3 data paths and data files.
# MAGIC
# MAGIC ## Key Concepts
# MAGIC
# MAGIC 1. **Jobs**: In Databricks, jobs are scheduled runs of notebooks or scripts for data pipelines.
# MAGIC 2. **Tasks**: Individual actions within a job, like running a notebook, JAR, or Python script.
# MAGIC 3. **Scheduling**: Databricks Jobs can be scheduled, triggered manually, or run based on dependencies.
# MAGIC 4. **Alerts and Monitoring**: Allows monitoring of jobs, with alert notifications for successes or failures.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Workflow Example Overview
# MAGIC
# MAGIC We'll set up a workflow with the following steps:
# MAGIC 1. **Ingest Bank Data from S3**: Reads the `bank-customers.csv` from your S3 path.
# MAGIC 2. **Transform and Write to Delta Lake**: Processes the data and saves it in Delta format.
# MAGIC 3. **Validate Data Quality**: Ensures data meets quality standards.
# MAGIC 4. **Notify on Completion**: Sends a notification upon successful completion of the workflow.
# MAGIC
# MAGIC The paths used:
# MAGIC - **Data Path**: `/mnt/s3dataread/bank-customers.csv`
# MAGIC - **Delta Lake Storage Path**: `/mnt/s3dataread/output-bank-customers/delta`
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 1. Create a Job in Databricks
# MAGIC
# MAGIC To create a job in the Databricks UI:
# MAGIC 1. Go to **Jobs** and click **Create Job**.
# MAGIC 2. Name the job (e.g., “Bank Data Pipeline”).
# MAGIC 3. Configure the tasks (details below), select clusters, and set schedules.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 2. Define and Run Each Task
# MAGIC
# MAGIC Each task is set up as a standalone notebook or script in Databricks, which we’ll organize here.
# MAGIC
# MAGIC #### Task 1: Ingest Data from S3
# MAGIC
# MAGIC Ingests data from the specified S3 path and reads it into a DataFrame.

# COMMAND ----------

# Load Bank Data from S3 path
csv_data_path = "/mnt/s3dataread/bank-customers.csv"
bank_df = spark.read.csv(csv_data_path, header=True, inferSchema=True)

# Display a sample of the data
bank_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC *Set this as a standalone task in Databricks by running it as a job or task in a job sequence.*
# MAGIC
# MAGIC #### Task 2: Transform and Write to Delta Lake
# MAGIC
# MAGIC This task processes the data by adding a processing timestamp and writing the output to Delta Lake for reliable storage.

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# Add a processing timestamp column
processed_bank_df = bank_df.withColumn("processed_timestamp", current_timestamp())

# Define Delta Lake path
delta_path = "/mnt/s3dataread/output-bank-customers/delta"

# Write to Delta Lake with overwrite mode and enable schema evolution
processed_bank_df.write.format("delta") \
    .option("mergeSchema", "true") \
    .mode("overwrite") \
    .save(delta_path)

# Display a message indicating successful transformation
print("Data has been transformed and written to Delta Lake.")

# COMMAND ----------

# MAGIC %md
# MAGIC *Configure this as Task 2 in the job workflow, with Task 1 as its dependency.*
# MAGIC
# MAGIC #### Task 3: Validate Data Quality
# MAGIC
# MAGIC This task checks data quality, such as ensuring no critical columns are null, and records the count of rows that meet certain criteria.

# COMMAND ----------

# Load processed data from Delta Lake
validated_df = spark.read.format("delta").load(delta_path)

# Check for null values in critical columns
critical_columns = ["balance", "job"]

# Calculate the count of rows with nulls in critical columns
null_counts = {col: validated_df.filter(validated_df[col].isNull()).count() for col in critical_columns}

# Print validation summary
for col, count in null_counts.items():
    print(f"Column {col} has {count} null values")

# Raise an alert if any critical column has nulls
if any(count > 0 for count in null_counts.values()):
    print("Validation failed: critical columns contain null values.")
else:
    print("Validation passed: No null values found in critical columns.")

# COMMAND ----------

# MAGIC %md
# MAGIC *Add this as Task 3 in the workflow, with a dependency on Task 2.*
# MAGIC
# MAGIC #### Task 4: Notify on Completion
# MAGIC
# MAGIC This final task is triggered upon successful completion of all previous tasks. It sends a notification indicating workflow completion.

# COMMAND ----------

# Print completion message
print("All workflow tasks have completed successfully!")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### 3. Set Up Dependencies Between Tasks
# MAGIC
# MAGIC In the Databricks **Jobs** interface:
# MAGIC 1. **Create each task** as a separate Databricks task or notebook task.
# MAGIC 2. **Set dependencies**: For example, set Task 2 (Transform) to depend on Task 1 (Ingest), Task 3 (Validate) on Task 2, and Task 4 (Notify) on Task 3.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 4. Schedule the Job
# MAGIC
# MAGIC 1. In the Databricks **Jobs** UI, navigate to the job you created.
# MAGIC 2. Select **Schedule** and configure the frequency (e.g., daily at a specific time).
# MAGIC 3. Save the schedule.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 5. Alerts and Monitoring
# MAGIC
# MAGIC Set up alerts to notify on job statuses:
# MAGIC - **Success**: To confirm the workflow ran successfully.
# MAGIC - **Failure**: To immediately address any issues.
# MAGIC
# MAGIC 1. In the **Jobs** UI, select the job.
# MAGIC 2. Go to **Alerts** and configure notifications (e.g., email alerts).
# MAGIC
# MAGIC ---
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### Summary
# MAGIC
# MAGIC In this notebook, we demonstrated how to:
# MAGIC 1. **Ingest data from S3**.
# MAGIC 2. **Transform and save data in Delta Lake** for reliable storage.
# MAGIC 3. **Validate data quality**.
# MAGIC 4. **Notify on successful workflow completion**.