# Databricks notebook source
# MAGIC %md
# MAGIC # Utilizing Delta Lake for Reliable Storage in Databricks
# MAGIC
# MAGIC This guide demonstrates how to use Delta Lake for reliable storage in Databricks. Delta Lake adds ACID transactions and other data management features to Apache Spark, which are essential for building reliable data pipelines and analytics.
# MAGIC
# MAGIC ### Key Delta Lake Features:
# MAGIC - **ACID Transactions**: Ensure data reliability with atomicity, consistency, isolation, and durability.
# MAGIC - **Schema Enforcement and Evolution**: Enforce schema during writes and support schema updates.
# MAGIC - **Time Travel**: Query previous versions of data.
# MAGIC - **Optimizations**: Efficient storage and fast queries with data compaction and indexing.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Setup and Configuration
# MAGIC
# MAGIC We'll begin by configuring Delta Lake in Databricks and defining paths for storing Delta tables. This example assumes that data is stored in an AWS S3 bucket mounted on Databricks.

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from delta.tables import DeltaTable

# Configurations for Delta Lake in Databricks
#spark.conf.set("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
#spark.conf.set("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")

# Define paths for Delta Lake table storage using S3 mount
csv_data_path = "/mnt/s3dataread/bank-customers.csv"  # Example CSV input
delta_path = "/mnt/s3dataread/output-bank-customers/delta"  # Delta Lake storage path

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Load Data and Initial Delta Lake Write
# MAGIC
# MAGIC Let's load a sample dataset (Bank Data) from the S3 bucket and write it to Delta Lake. This will be our initial setup to demonstrate Delta Lake's storage and schema management.

# COMMAND ----------

# Load the Bank Data from S3 bucket
bank_df = spark.read.csv(csv_data_path, header=True, inferSchema=True)

# Display a few rows of the data
bank_df.show(5)

# Write data to Delta Lake (initial write)
bank_df.write.format("delta").mode("overwrite").save(delta_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Schema Enforcement and Evolution
# MAGIC
# MAGIC Delta Lake enforces schemas, ensuring data consistency during writes. We'll demonstrate what happens when a schema mismatch occurs and show how to evolve the schema to accept new columns.
# MAGIC
# MAGIC ### Schema Enforcement

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Schema Evolution
# MAGIC
# MAGIC To allow the new column, enable `mergeSchema` option to evolve the Delta Lake schema:

# COMMAND ----------

# Attempt to write data with a different schema (extra column added)
from pyspark.sql.types import StructType, StructField, IntegerType, StringType
from pyspark.sql import Row
from pyspark.sql.functions import lit

# Define a new schema with an additional column
new_data_with_extra_column = bank_df.withColumn("new_column", lit(None).cast(IntegerType()))

# Try writing to Delta Lake (this should raise a schema mismatch error)
try:
    new_data_with_extra_column.write.format("delta").mode("append").save(delta_path)
except Exception as e:
    print("Schema mismatch error:", e)

# Write with schema evolution
new_data_with_extra_column.write.option("mergeSchema", "true").format("delta").mode("append").save(delta_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## ACID Transactions: Updates, Deletes, and Upserts
# MAGIC
# MAGIC Delta Lake supports reliable data management through ACID transactions, allowing for updates, deletes, and merges (upserts).
# MAGIC
# MAGIC ### Upsert (Merge) Example
# MAGIC
# MAGIC Upsert operations allow inserting new records and updating existing records based on a condition.

# COMMAND ----------

from pyspark.sql.functions import col

# Add 1000 to the balance for the first 5 records
updated_data = bank_df.limit(5).withColumn("balance", col("balance") + 1000)

# Write the updated data back to the Delta table by overwriting the matching rows
delta_table.alias("target") \
    .merge(
        updated_data.alias("source"),
        "target.age = source.age"  # Assuming 'age' acts as an identifier for matching records
    ) \
    .whenMatchedUpdate(set={"balance": "source.balance"}) \
    .execute()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Delete Records Example

# COMMAND ----------

# Delete records where balance is below a certain threshold
delta_table.delete("balance < 0")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Time Travel in Delta Lake
# MAGIC
# MAGIC Delta Lake’s Time Travel feature enables querying previous versions of data, which is valuable for data auditing, debugging, and historical analysis.
# MAGIC
# MAGIC ### Example of Time Travel

# COMMAND ----------

# View the history of the Delta table to see available versions
delta_table.history().show()

# Query an older version of the data (e.g., version 0)
old_version_df = spark.read.format("delta").option("versionAsOf", 0).load(delta_path)
old_version_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Query by Timestamp

# COMMAND ----------

# Example of querying a specific timestamp (replace with actual timestamp)
timestamp = "2024-11-12T01:11:28.000Z"
time_travel_df = spark.read.format("delta").option("timestampAsOf", timestamp).load(delta_path)
display(time_travel_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Data Compaction and Optimization
# MAGIC
# MAGIC Delta Lake provides optimizations such as data compaction, which consolidates smaller files into larger ones, improving query performance.

# COMMAND ----------

# Compact small files in the Delta table into a single file
delta_table.optimize().executeCompaction()

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Additional Delta Lake Features
# MAGIC
# MAGIC ### 1. Z-Ordering for Faster Queries
# MAGIC
# MAGIC Z-Ordering optimizes data storage for faster querying by organizing the data files according to specified columns.

# COMMAND ----------

# Apply Z-Ordering on the "age" column for optimized storage
delta_table.optimize().executeZOrderBy("age")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. VACUUM to Clean Up Old Versions
# MAGIC
# MAGIC Delta Lake retains older data versions for Time Travel. To clean up these old files and reclaim storage, use `VACUUM`.

# COMMAND ----------

# Run VACUUM to remove files older than a specified retention period (e.g., 7 days)
delta_table.vacuum(retentionHours=168)  # 7 days in hours

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Summary
# MAGIC
# MAGIC In this guide, we explored Delta Lake's core features:
# MAGIC 1. **Setup and Configuration**: Configured Delta Lake in Databricks.
# MAGIC 2. **Initial Write**: Loaded data into Delta format.
# MAGIC 3. **Schema Enforcement and Evolution**: Enforced schema consistency and demonstrated schema evolution.
# MAGIC 4. **ACID Transactions**: Showed how to update, delete, and upsert records reliably.
# MAGIC 5. **Time Travel**: Queried historical data for audit and debugging.
# MAGIC 6. **Optimizations**: Demonstrated data compaction, Z-Ordering, and VACUUM to optimize storage.
# MAGIC
# MAGIC Delta Lake is an ideal solution for building reliable, performant data pipelines. Let me know if further examples are needed, or if there are specific scenarios you’d like to explore!