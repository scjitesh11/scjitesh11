# Databricks notebook source
# MAGIC %md
# MAGIC # Monitoring and Optimizing Pipeline Performance in Databricks
# MAGIC
# MAGIC ## 1. Introduction to Pipeline Monitoring and Optimization
# MAGIC
# MAGIC Monitoring and optimizing pipeline performance is crucial for managing resource costs, meeting SLAs, and ensuring data pipeline reliability. This guide focuses on techniques to monitor and improve the performance of Databricks data pipelines.
# MAGIC
# MAGIC ### Key Benefits:
# MAGIC - **Identify and Resolve Bottlenecks**: Quickly pinpoint and address performance issues.
# MAGIC - **Optimize Resource Utilization**: Ensure efficient use of resources to reduce costs.
# MAGIC - **Improve Data Throughput and Latency**: Enable faster data processing for real-time analytics and decision-making.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Step 1: Set Up Basic Monitoring in Databricks
# MAGIC
# MAGIC Databricks provides several built-in tools for monitoring pipelines. Start by setting up basic monitoring tools available in the Databricks UI.
# MAGIC
# MAGIC ### 2.1 Databricks Job UI
# MAGIC
# MAGIC 1. **Navigate to Jobs**: In the **Workflows** tab, go to **Jobs** to view pipeline tasks.
# MAGIC 2. **Check Task Status and Duration**: For each task, view its execution status, duration, and logs.
# MAGIC 3. **Access Logs**: Download and analyze log files to diagnose errors or identify slow operations.
# MAGIC
# MAGIC ### 2.2 Delta Live Tables (DLT) Monitoring UI
# MAGIC
# MAGIC Delta Live Tables pipelines provide additional metrics for monitoring:
# MAGIC - **View Table Lineage**: In the DLT UI, view the lineage and status of each table in the pipeline.
# MAGIC - **Latency Metrics**: Check data latency and processing times for real-time insights.
# MAGIC - **Data Quality Metrics**: Monitor the success rate of data quality checks, if defined.
# MAGIC
# MAGIC ### 2.3 Stream Progress
# MAGIC
# MAGIC If you are running a streaming pipeline, use the `lastProgress` method to get the current status of the streaming job.

# COMMAND ----------

# Example of checking streaming progress
streaming_query = raw_data_df.writeStream.format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", "dbfs:/mnt/s3dataread/checkpoints/streaming_query-16") \
    .table("realtime_data")

# Display the progress of the streaming job
display(streaming_query.lastProgress)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 3. Step 2: Using Delta Live Tables (DLT) Metrics
# MAGIC
# MAGIC DLT offers a detailed monitoring interface specifically designed for data workflows, enabling you to observe:
# MAGIC - **Data Quality Metrics**: View failed rows and successful checks for each `dlt.expect` rule.
# MAGIC - **Performance Metrics**: Track throughput, latency, and error counts for each transformation.
# MAGIC - **Alerting**: Set up alerts for any DLT table with high error rates or failed expectations.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 4. Step 3: Diagnosing Performance Bottlenecks
# MAGIC
# MAGIC Diagnose performance issues by analyzing the Spark UI and DLT metrics.
# MAGIC
# MAGIC ### 4.1 Analyze Spark UI Metrics
# MAGIC
# MAGIC The Spark UI provides a comprehensive view of each stage and task within your pipeline.
# MAGIC
# MAGIC 1. **Job and Stage Metrics**:
# MAGIC    - **Execution Time**: Check job and stage durations to identify slow operations.
# MAGIC    - **Shuffle and Spill**: High shuffle times indicate excessive data movement across nodes.
# MAGIC    - **Skewed Tasks**: Detect skew by looking at task execution times and identifying tasks that take disproportionately longer.
# MAGIC
# MAGIC 2. **SQL Tab**:
# MAGIC    - View the physical query plan and execution time for each query.
# MAGIC    - **Filter and Join Operations**: Expensive filters, joins, or aggregations can cause slowdowns, especially if data is not partitioned or filtered correctly.
# MAGIC
# MAGIC 3. **Storage Tab**:
# MAGIC    - Check storage metrics to see if data caching and memory usage are optimized.
# MAGIC    - **Memory Overflows**: Look for signs of spilling, which indicate insufficient memory.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 5. Step 4: Optimizing Data Processing
# MAGIC
# MAGIC Improve the efficiency of your pipeline by optimizing transformations and enabling adaptive query execution.
# MAGIC
# MAGIC ### 5.1 Data Caching
# MAGIC
# MAGIC Cache frequently used DataFrames to reduce redundant computation and improve performance.

# COMMAND ----------

# Cache the DataFrame for reuse in subsequent operations
transformed_df.cache()
transformed_df.count()  # Trigger the cache

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5.2 Adaptive Query Execution (AQE)
# MAGIC
# MAGIC Enable **Adaptive Query Execution** (AQE) in Spark to dynamically optimize queries based on runtime metrics.

# COMMAND ----------

# Enable AQE in Spark
spark.conf.set("spark.sql.adaptive.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC AQE optimizes:
# MAGIC - **Join Strategies**: Dynamically changes join strategies based on data statistics.
# MAGIC - **Shuffle Partitions**: Adjusts shuffle partition sizes to reduce data shuffling.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 6. Step 5: Delta Lake Optimizations
# MAGIC
# MAGIC Delta Lake offers several optimizations to improve read and write performance, especially on large tables.
# MAGIC
# MAGIC ### 6.1 Data Compaction (Optimize Command)
# MAGIC
# MAGIC Data compaction merges small files into larger files, reducing I/O overhead and improving query speed.

# COMMAND ----------

from delta.tables import DeltaTable

# Define Delta Table
delta_table_path = "/mnt/s3dataread/my_table/"
delta_table = DeltaTable.forPath(spark, delta_table_path)

# Optimize and compact small files
delta_table.optimize().executeCompaction()
print("Data compaction completed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 6.2 Z-Ordering for Efficient Filtering
# MAGIC
# MAGIC **Z-ordering** improves query performance by clustering frequently filtered columns together, which reduces the amount of data scanned.

# COMMAND ----------

# Z-order on a frequently filtered column, e.g., customer_id
delta_table.optimize().executeZOrderBy("customer_id")
print("Z-ordering on customer_id completed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 7. Step 6: Monitoring and Configuring Cluster Resources
# MAGIC
# MAGIC Monitor cluster resource utilization and adjust configurations to optimize pipeline performance.
# MAGIC
# MAGIC ### 7.1 Monitor Cluster Metrics
# MAGIC
# MAGIC In the **Cluster** tab, view CPU, memory, and disk utilization metrics for each node to ensure resources are adequate.
# MAGIC
# MAGIC 1. **CPU and Memory Utilization**:
# MAGIC    - Check if CPU or memory is consistently at maximum. If so, consider scaling up (adding larger instances) or scaling out (adding more instances).
# MAGIC    
# MAGIC 2. **Disk Usage**:
# MAGIC    - Monitor disk I/O and storage metrics to ensure there is enough space, especially if the pipeline writes large datasets.
# MAGIC
# MAGIC ### 7.2 Configure Cluster for Performance
# MAGIC
# MAGIC #### Scaling and Autoscaling
# MAGIC
# MAGIC 1. **Cluster Size**:
# MAGIC    - Use clusters with more nodes or higher memory to handle large workloads.
# MAGIC    - For streaming or real-time workloads, ensure that the cluster has low latency and can handle spikes in data volume.
# MAGIC
# MAGIC 2. **Autoscaling**:
# MAGIC    - Enable autoscaling to dynamically adjust cluster size based on workload demand.
# MAGIC
# MAGIC #### Instance Types
# MAGIC
# MAGIC Use **memory-optimized instances** for data-heavy transformations and **compute-optimized instances** for CPU-intensive tasks.
# MAGIC
# MAGIC ### 7.3 Task Parallelism and Partitioning
# MAGIC
# MAGIC Increase task parallelism by optimizing partitioning strategies.
# MAGIC
# MAGIC 1. **Optimize Shuffle Partitions**:
# MAGIC    - Set `spark.sql.shuffle.partitions` to an appropriate value based on data size and cluster resources.

# COMMAND ----------

# Set the shuffle partitions for optimal performance
spark.conf.set("spark.sql.shuffle.partitions", "200")  # Adjust as needed

# COMMAND ----------

# MAGIC %md
# MAGIC 2. **Repartitioning DataFrames**:
# MAGIC    - Repartition DataFrames based on key columns to optimize joins and aggregations.

# COMMAND ----------

# Repartition based on a column (e.g., customer_id) to optimize join performance
transformed_df = transformed_df.repartition("customer_id")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## Summary
# MAGIC
# MAGIC This guide covered **Monitoring and Optimizing Pipeline Performance in Databricks** by:
# MAGIC 1. **Setting Up Monitoring Tools**: Used Databricks Job UI, Delta Live Tables metrics, and streaming progress tools for pipeline monitoring.
# MAGIC 2. **Diagnosing Bottlenecks**: Used Spark UI and SQL tab metrics to identify slowdowns and optimize joins, filters, and shuffles.
# MAGIC 3. **Optimizing Data Processing**: Employed caching and Adaptive Query Execution to improve data transformation performance.
# MAGIC 4. **Delta Lake Optimizations**: Applied data compaction and Z-ordering to enhance data storage and retrieval speeds.
# MAGIC 5. **Cluster Resource Configuration**: Monitored resource usage, configured autoscaling, and optimized partitioning to achieve better parallelism.