# Databricks notebook source
# MAGIC %md
# MAGIC # Handling Data Partitioning and Distribution for Efficiency
# MAGIC
# MAGIC
# MAGIC ## 1. Introduction to Data Partitioning and Distribution
# MAGIC
# MAGIC **Data Partitioning** is the process of dividing a dataset into smaller, manageable segments based on specific keys or columns. Effective partitioning improves data processing speed, parallelism, and resource efficiency by allowing Spark and Databricks to handle data in smaller chunks and optimize resource usage.
# MAGIC
# MAGIC **Distribution** refers to how data is spread across nodes in a Spark cluster. Proper data distribution ensures that tasks are balanced and minimizes data shuffling, resulting in faster query execution and better scalability.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Why Partitioning Matters
# MAGIC
# MAGIC Partitioning helps in:
# MAGIC - **Improving Query Performance**: Filtering queries can scan only relevant partitions, reducing the amount of data read.
# MAGIC - **Resource Optimization**: By controlling the size of partitions, you ensure that Spark tasks are efficiently sized, leading to better resource utilization.
# MAGIC - **Reducing Data Shuffling**: Partitioning reduces the need to move data between nodes in the cluster, especially during operations like joins and aggregations.
# MAGIC - **Enabling Parallelism**: Partitions can be processed independently and in parallel, maximizing Spark’s distributed computing capabilities.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 3. Partitioning Strategies
# MAGIC
# MAGIC Choosing the right partitioning strategy depends on your data characteristics, query patterns, and storage format.
# MAGIC
# MAGIC ### Column-Based Partitioning
# MAGIC
# MAGIC Partition data based on commonly queried columns (e.g., `country`, `customer_id`). Column-based partitioning works well for categorical data with relatively low cardinality.
# MAGIC
# MAGIC #### Example

# COMMAND ----------

df.write.format("delta").mode("overwrite").partitionBy("country").save("/mnt/delta/retail_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Time-Based Partitioning
# MAGIC
# MAGIC Partitioning by time-based columns (e.g., `year`, `month`, `day`) is useful for data that grows over time, such as logs or transactions.
# MAGIC
# MAGIC #### Example

# COMMAND ----------

from pyspark.sql.functions import year, month, dayofmonth

# Add partitioning columns
df = df.withColumn("year", year("transaction_date")).withColumn("month", month("transaction_date"))

# Partition by year and month
df.write.format("delta").mode("overwrite").partitionBy("year", "month").save("/mnt/delta/retail_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Hash-Based Partitioning
# MAGIC
# MAGIC Hash-based partitioning distributes data evenly across partitions based on a hash of a key column. This approach is useful for skewed data and load balancing.
# MAGIC
# MAGIC #### Example

# COMMAND ----------

# Repartition data based on a hash of customer_id
df = df.repartition(10, "customer_id")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 4. Data Partitioning in Delta Lake
# MAGIC
# MAGIC Delta Lake, with its transactional capabilities, provides additional features for managing partitioned data efficiently.
# MAGIC
# MAGIC ### Choosing the Right Partition Columns
# MAGIC
# MAGIC 1. **Analyze Query Patterns**:
# MAGIC    - Select partition columns that are frequently used in filtering or grouping operations to minimize the amount of data scanned.
# MAGIC    
# MAGIC 2. **Avoid High Cardinality Columns**:
# MAGIC    - Columns with many unique values (high cardinality) can lead to too many small partitions, which degrade performance.
# MAGIC    
# MAGIC 3. **Limit the Number of Partitions**:
# MAGIC    - Over-partitioning can create too many files and lead to excessive metadata overhead.
# MAGIC
# MAGIC ### Managing Small Files
# MAGIC
# MAGIC Small files can reduce read performance and increase storage costs. Delta Lake supports **data compaction** to optimize partition files.
# MAGIC
# MAGIC #### Compacting Small Files
# MAGIC
# MAGIC Use the **OPTIMIZE** command to compact small files within each partition.

# COMMAND ----------

from delta.tables import DeltaTable

# Define the Delta table path
delta_table_path = "/mnt/delta/retail_data"
delta_table = DeltaTable.forPath(spark, delta_table_path)

# Compact small files
delta_table.optimize().executeCompaction()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Z-Ordering for Partitioned Data
# MAGIC
# MAGIC **Z-ordering** clusters data within each partition by frequently queried columns, reducing the amount of data read during scans.

# COMMAND ----------

# Apply Z-ordering on the partitioned table for the "customer_id" column
delta_table.optimize().executeZOrderBy("customer_id")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 5. Optimizing Partitioning for Spark Performance
# MAGIC
# MAGIC Spark provides additional methods for controlling partitioning and minimizing data shuffling during transformations.
# MAGIC
# MAGIC ### Repartitioning and Coalescing
# MAGIC
# MAGIC - **Repartitioning**: Increases the number of partitions, often used before expensive transformations to balance the load across nodes.
# MAGIC
# MAGIC    ```python
# MAGIC    df = df.repartition(10, "country")
# MAGIC    ```
# MAGIC
# MAGIC - **Coalescing**: Reduces the number of partitions, commonly used before writing to reduce the number of output files.
# MAGIC
# MAGIC    ```python
# MAGIC    df = df.coalesce(4)
# MAGIC    ```
# MAGIC
# MAGIC ### Skewed Data Management
# MAGIC
# MAGIC Skewed data causes uneven distribution, where certain partitions are larger than others. This can result in slow tasks and inefficient resource use.
# MAGIC
# MAGIC #### Solutions:
# MAGIC - **Salting**: Add a random salt value to the key to distribute data more evenly.
# MAGIC
# MAGIC    ```python
# MAGIC    from pyspark.sql.functions import rand
# MAGIC
# MAGIC    # Add a salt column for better distribution
# MAGIC    df = df.withColumn("salted_key", (col("customer_id") + rand()).cast("int"))
# MAGIC    df = df.repartition(10, "salted_key")
# MAGIC    ```
# MAGIC
# MAGIC - **Custom Partitioning**: Use `repartitionByRange` if your data has a natural range or order, such as dates.
# MAGIC
# MAGIC    ```python
# MAGIC    df = df.repartitionByRange("transaction_date")
# MAGIC    ```
# MAGIC
# MAGIC ### Dynamic Partition Pruning
# MAGIC
# MAGIC Dynamic Partition Pruning (DPP) is a Spark optimization that dynamically prunes partitions based on the results of a join. This reduces the amount of data scanned in downstream stages.
# MAGIC
# MAGIC #### Enabling DPP in Spark

# COMMAND ----------

# Enable Dynamic Partition Pruning
spark.conf.set("spark.sql.optimizer.dynamicPartitionPruning.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 6. Best Practices for Partitioning
# MAGIC
# MAGIC 1. **Partition on Frequently Queried Columns**:
# MAGIC    - Choose partition keys based on columns used frequently in WHERE clauses.
# MAGIC
# MAGIC 2. **Limit Partition Levels**:
# MAGIC    - Avoid over-partitioning. Generally, partition on up to 2-3 columns to avoid excessive small files.
# MAGIC
# MAGIC 3. **Compact Files Periodically**:
# MAGIC    - Use the Delta Lake OPTIMIZE command periodically on your Delta tables to compact files and improve query performance.
# MAGIC
# MAGIC 4. **Balance Repartitioning and Coalescing**:
# MAGIC    - Use `repartition` to distribute data evenly for heavy transformations and `coalesce` before output to minimize the number of output files.
# MAGIC
# MAGIC 5. **Monitor and Adjust**:
# MAGIC    - Regularly monitor data access patterns and performance to refine your partitioning strategy.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 7. Summary
# MAGIC
# MAGIC This guide covered the essentials of **Handling Data Partitioning and Distribution for Efficiency** in Databricks, focusing on Delta Lake and Spark optimizations.
# MAGIC
# MAGIC 1. **Partitioning Strategies**:
# MAGIC    - Explained column-based, time-based, and hash-based partitioning techniques.
# MAGIC
# MAGIC 2. **Delta Lake Partitioning**:
# MAGIC    - Discussed choosing partition columns, managing small files, and using Delta Lake features like Z-ordering and compaction.
# MAGIC
# MAGIC 3. **Spark Performance Optimizations**:
# MAGIC    - Covered repartitioning, coalescing, salting for skewed data, and Dynamic Partition Pruning for query performance.