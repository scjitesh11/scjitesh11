# Databricks notebook source
# MAGIC %md
# MAGIC # Integrating Databricks with AWS Step Functions for Complex Workflows
# MAGIC
# MAGIC In this guide, we’ll explore how to integrate AWS Step Functions with Databricks to build complex, multi-step data workflows. **AWS Step Functions** provide robust orchestration capabilities to manage data pipelines, automating and coordinating multiple Databricks tasks.
# MAGIC
# MAGIC ### Key Benefits of Using AWS Step Functions with Databricks:
# MAGIC - **Orchestration Across Services**: Enables seamless integration between Databricks and other AWS services (e.g., S3, Lambda, Redshift).
# MAGIC - **Error Handling and Retries**: Manages retries, error handling, and logging, providing robust management of data workflows.
# MAGIC - **Parallel Execution**: Supports parallelism to run multiple tasks simultaneously.
# MAGIC - **State Management**: Tracks the state of each step and records transitions, ensuring workflows are reliable.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Prerequisites
# MAGIC
# MAGIC 1. **AWS Permissions**: Ensure the necessary permissions for AWS Step Functions, Lambda, and any other AWS services used (e.g., IAM roles for access control).
# MAGIC 2. **Databricks Access Token**: Generate a Databricks API token to authorize Step Functions to interact with Databricks Jobs.
# MAGIC 3. **Databricks Jobs**: Preconfigure Databricks Jobs that you want to orchestrate.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Workflow Outline
# MAGIC
# MAGIC We’ll set up a sample complex workflow with the following steps:
# MAGIC
# MAGIC 1. **Step 1**: Trigger Databricks to ingest data from S3 (bank-customers.csv).
# MAGIC 2. **Step 2**: Process and transform data in Databricks and write it to Delta Lake.
# MAGIC 3. **Step 3**: Validate the transformed data.
# MAGIC 4. **Step 4**: Notify completion of the workflow.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 1. Set Up Databricks Jobs
# MAGIC
# MAGIC Before configuring AWS Step Functions, create the Databricks jobs required for each step. These jobs should be accessible via the Databricks REST API.
# MAGIC
# MAGIC #### Example Databricks Jobs
# MAGIC
# MAGIC Here’s an example structure for each Databricks job:
# MAGIC
# MAGIC **Job 1: Data Ingestion**

# COMMAND ----------

# Ingest Bank Data from S3
s3_data_path = "/mnt/s3dataread/bank-customers.csv"
bank_df = spark.read.csv(s3_data_path, header=True, inferSchema=True)
bank_df.write.format("delta").mode("overwrite").save("/mnt/s3dataread/delta/bank_data")
print("Data ingestion completed.")

# COMMAND ----------

# MAGIC %md
# MAGIC **Job 2: Data Transformation**

# COMMAND ----------

# Load data from Delta Lake
bank_df = spark.read.format("delta").load("/mnt/s3dataread/delta/bank_data")
transformed_df = bank_df.withColumn("processed_date", current_date())
transformed_df.write.format("delta").mode("overwrite").save("/mnt/s3dataread/delta/transformed_bank_data")
print("Data transformation completed.")

# COMMAND ----------

# MAGIC %md
# MAGIC **Job 3: Data Validation**

# COMMAND ----------

# Load transformed data and validate
transformed_df = spark.read.format("delta").load("/mnt/s3dataread/delta/transformed_bank_data")
null_counts = {col: transformed_df.filter(transformed_df[col].isNull()).count() for col in transformed_df.columns}

for col, count in null_counts.items():
    print(f"{col}: {count} null values")

if any(count > 0 for count in null_counts.values()):
    raise ValueError("Validation failed: Null values found.")
print("Validation passed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### 2. Create a Lambda Function to Trigger Databricks Jobs
# MAGIC
# MAGIC AWS Step Functions will use AWS Lambda to initiate Databricks jobs via the Databricks REST API. Follow these steps to create a Lambda function for triggering jobs:
# MAGIC
# MAGIC #### Lambda Function Code (Python)
# MAGIC
# MAGIC Here’s a sample Lambda function to start a Databricks job:

# COMMAND ----------

import json
import boto3
import requests

def lambda_handler(event, context):
    # Databricks API details
    DATABRICKS_INSTANCE = 'https://<databricks-instance>.cloud.databricks.com'
    TOKEN = '<your-databricks-token>'
    JOB_ID = event['job_id']  # Pass the job ID via Step Functions
    
    # Start the Databricks job
    url = f"{DATABRICKS_INSTANCE}/api/2.0/jobs/run-now"
    headers = {'Authorization': f'Bearer {TOKEN}'}
    data = {"job_id": JOB_ID}
    response = requests.post(url, headers=headers, json=data)
    
    # Parse and return the response
    response_json = response.json()
    return {
        'statusCode': 200,
        'body': json.dumps(response_json)
    }

# COMMAND ----------

# MAGIC %md
# MAGIC #### Lambda Function Configuration
# MAGIC
# MAGIC
# MAGIC #### IAM Role for Lambda
# MAGIC
# MAGIC Ensure your Lambda function’s IAM role has permissions to call the necessary Databricks APIs and AWS services (e.g., logging permissions in CloudWatch).
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 3. Configure AWS Step Functions
# MAGIC
# MAGIC 1. **Create a New State Machine**:
# MAGIC    - In the AWS Management Console, go to **Step Functions** and create a new state machine.
# MAGIC    - Use the **Standard** workflow for this setup.
# MAGIC
# MAGIC 2. **Define the Workflow States**:
# MAGIC    - Use the **Amazon States Language** to define each task, its dependencies, and conditions.
# MAGIC    - Here’s an example definition for the workflow states:
# MAGIC
# MAGIC ```json
# MAGIC {
# MAGIC   "Comment": "Databricks Orchestration with Step Functions",
# MAGIC   "StartAt": "Ingest Data",
# MAGIC   "States": {
# MAGIC     "Ingest Data": {
# MAGIC       "Type": "Task",
# MAGIC       "Resource": "arn:aws:lambda:<region>:<account-id>:function:StartDatabricksJob",
# MAGIC       "Parameters": {
# MAGIC         "job_id": "job_id_1"
# MAGIC       },
# MAGIC       "Next": "Transform Data"
# MAGIC     },
# MAGIC     "Transform Data": {
# MAGIC       "Type": "Task",
# MAGIC       "Resource": "arn:aws:lambda:<region>:<account-id>:function:StartDatabricksJob",
# MAGIC       "Parameters": {
# MAGIC         "job_id": "job_id_2"
# MAGIC       },
# MAGIC       "Next": "Validate Data"
# MAGIC     },
# MAGIC     "Validate Data": {
# MAGIC       "Type": "Task",
# MAGIC       "Resource": "arn:aws:lambda:<region>:<account-id>:function:StartDatabricksJob",
# MAGIC       "Parameters": {
# MAGIC         "job_id": "job_id_3"
# MAGIC       },
# MAGIC       "Next": "Notify Completion"
# MAGIC     },
# MAGIC     "Notify Completion": {
# MAGIC       "Type": "Succeed"
# MAGIC     }
# MAGIC   }
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC - **Ingest Data**: Initiates Job 1 for data ingestion.
# MAGIC - **Transform Data**: Runs Job 2 for data transformation.
# MAGIC - **Validate Data**: Runs Job 3 to validate the data.
# MAGIC - **Notify Completion**: Ends the workflow successfully.
# MAGIC
# MAGIC ### Explanation of Key Fields:
# MAGIC - `"Resource"`: Points to the Lambda function that starts a Databricks job.
# MAGIC - `"Parameters"`: Specifies the `job_id` parameter, which the Lambda function uses to select the appropriate Databricks job.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### 4. Monitor Workflow Execution
# MAGIC
# MAGIC AWS Step Functions provides detailed logging and tracking for each task:
# MAGIC 1. **Step-by-Step Execution**: View each task’s status in the **Execution** tab.
# MAGIC 2. **Logs and Retries**: Configure retries and catch failure conditions for error handling.
# MAGIC 3. **CloudWatch Integration**: View detailed logs for Lambda function executions and task status.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Example: Triggering and Running the Workflow
# MAGIC
# MAGIC After setting up:
# MAGIC 1. **Trigger the workflow** in AWS Step Functions.
# MAGIC 2. **Monitor execution** in real-time to observe the task transitions and status updates.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Summary
# MAGIC
# MAGIC In this guide, we explored:
# MAGIC 1. **Setting up Databricks Jobs**: Prepared each job as a standalone process in Databricks.
# MAGIC 2. **Creating Lambda Functions**: Set up Lambda functions to trigger Databricks jobs.
# MAGIC 3. **Configuring Step Functions**: Defined and managed task dependencies and execution order.
# MAGIC 4. **Monitoring and Error Handling**: Leveraged AWS Step Functions for monitoring and managing workflow reliability.