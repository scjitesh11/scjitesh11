# Databricks notebook source
import dlt
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

# Define the schema for raw transaction data
transaction_schema = StructType([
    StructField("transaction_id", StringType(), True),
    StructField("customer_id", IntegerType(), True),
    StructField("transaction_amount", DoubleType(), True),
    StructField("transaction_date", TimestampType(), True),
    StructField("country", StringType(), True)
])

@dlt.table(
    name="bronze_transactions",
    comment="Raw data ingestion from Kafka to Bronze layer"
)
def bronze_transactions():
    return (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", "52.178.146.226:9092,52.178.146.226:9093,52.178.146.226:9094")
        .option("subscribe", "retail_transactions")
        .option("startingOffsets", "latest")
        .load()
        .selectExpr("CAST(value AS STRING) as json")
        .select(from_json(col("json"), transaction_schema).alias("data"))
        .select("data.*")
    )

# COMMAND ----------

from pyspark.sql.functions import col, year, month

@dlt.table(
    name="silver_transactions",
    comment="Cleaned and enriched transactions data in Silver layer"
)
@dlt.expect("valid_transaction_amount", "transaction_amount > 0")
@dlt.expect("valid_customer_id", "customer_id IS NOT NULL AND customer_id > 0")
def silver_transactions():
    return (
        dlt.read("bronze_transactions")
        .dropDuplicates(["transaction_id"])
        .filter(col("transaction_date").isNotNull())
        .withColumn("year", year(col("transaction_date")))  # Use year() function
        .withColumn("month", month(col("transaction_date")))  # Use month() function
    )


# COMMAND ----------

@dlt.table(
    name="gold_country_sales",
    comment="Aggregated total sales by country in Gold layer"
)
def gold_country_sales():
    silver_transactions_df = dlt.read("silver_transactions")
    
    # Cache the dataframe
    silver_transactions_df = silver_transactions_df.cache()

    return (
        silver_transactions_df
        .groupBy("country")
        .agg({"transaction_amount": "sum"})
        .withColumnRenamed("sum(transaction_amount)", "total_sales")
    )