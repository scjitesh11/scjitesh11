# Databricks notebook source
from pyspark.sql.functions import current_date

# Load data from Delta Lake
bank_df = spark.read.format("delta").load("/mnt/s3dataread/delta/bank_data")
transformed_df = bank_df.withColumn("processed_date", current_date())
transformed_df.write.format("delta").mode("overwrite").save("/mnt/s3dataread/delta/transformed_bank_data")
print("Data transformation completed.")