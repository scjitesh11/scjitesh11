# Databricks notebook source
# Load transformed data and validate
transformed_df = spark.read.format("delta").load("/mnt/s3dataread/delta/transformed_bank_data")
null_counts = {col: transformed_df.filter(transformed_df[col].isNull()).count() for col in transformed_df.columns}

for col, count in null_counts.items():
    print(f"{col}: {count} null values")

if any(count > 0 for count in null_counts.values()):
    raise ValueError("Validation failed: Null values found.")
print("Validation passed.")