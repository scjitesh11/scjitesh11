# Databricks notebook source
# MAGIC %md
# MAGIC # Techniques to Optimize Cost and Performance of Data Pipelines in Databricks
# MAGIC
# MAGIC ## 1. Introduction to Cost and Performance Optimization
# MAGIC
# MAGIC Optimizing data pipelines in Databricks involves balancing performance with resource efficiency. By improving pipeline performance, you can achieve faster data processing times and minimize resource consumption, ultimately reducing costs. This guide will discuss key techniques to optimize both cost and performance.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Optimizing Data Processing with Spark
# MAGIC
# MAGIC Spark provides a variety of configurations and optimization techniques to manage data efficiently and improve processing speed.
# MAGIC
# MAGIC ### Partitioning and Distribution
# MAGIC
# MAGIC 1. **Repartitioning and Coalescing**:
# MAGIC    - **Repartition** increases parallelism by creating more partitions, especially useful before heavy transformations like joins and aggregations.
# MAGIC      ```python
# MAGIC      df = df.repartition(10, "key_column")
# MAGIC      ```
# MAGIC    - **Coalesce** reduces the number of partitions, typically before writing data to minimize small files.
# MAGIC      ```python
# MAGIC      df = df.coalesce(4)
# MAGIC      ```
# MAGIC
# MAGIC 2. **Skewed Data Management**:
# MAGIC    - Manage skewed data by salting keys or using custom partitioning, ensuring even distribution and reducing long-running tasks.
# MAGIC
# MAGIC 3. **Dynamic Partition Pruning (DPP)**:
# MAGIC    - Enable DPP to reduce data scans in downstream operations, particularly joins.
# MAGIC      ```python
# MAGIC      spark.conf.set("spark.sql.optimizer.dynamicPartitionPruning.enabled", "true")
# MAGIC      ```
# MAGIC
# MAGIC ### Caching and Persistence
# MAGIC
# MAGIC Caching frequently accessed DataFrames can reduce redundant computations and improve performance, especially for iterative or complex transformations.

# COMMAND ----------

df.cache()
df.count()  # Trigger cache

# COMMAND ----------

# MAGIC %md
# MAGIC Consider using `persist()` with a storage level (e.g., `MEMORY_AND_DISK`) if data is too large to fit in memory.
# MAGIC
# MAGIC ### Adaptive Query Execution (AQE)
# MAGIC
# MAGIC Enable AQE to allow Spark to optimize queries at runtime based on the actual data distribution, especially useful for handling unpredictable data sizes or skewed joins.

# COMMAND ----------

spark.conf.set("spark.sql.adaptive.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC AQE dynamically adjusts:
# MAGIC - **Shuffle Partitions**: Reduces the number of partitions for small datasets.
# MAGIC - **Join Strategies**: Optimizes join types (e.g., switch from broadcast join to sort-merge join).
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 3. Delta Lake Optimizations
# MAGIC
# MAGIC Delta Lake enhances cost-efficiency and performance with ACID compliance, schema management, and data optimization features.
# MAGIC
# MAGIC ### Data Compaction (Optimize Command)
# MAGIC
# MAGIC Use Delta Lake’s **Optimize** command to compact small files into larger ones, reducing metadata overhead and improving read performance.

# COMMAND ----------

from delta.tables import DeltaTable

delta_table_path = "/mnt/delta/table"
delta_table = DeltaTable.forPath(spark, delta_table_path)

# Compact files
delta_table.optimize().executeCompaction()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Z-Ordering for Efficient Filtering
# MAGIC
# MAGIC **Z-ordering** optimizes data layout by clustering frequently queried columns, which reduces the amount of data scanned for specific queries.

# COMMAND ----------

# Apply Z-ordering on a frequently queried column
delta_table.optimize().executeZOrderBy("customer_id")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Schema Evolution
# MAGIC
# MAGIC Delta Lake supports automatic schema evolution, allowing data pipelines to adapt to changing data schemas without manual intervention. This reduces downtime and increases pipeline resilience.

# COMMAND ----------

# Enable schema evolution
df.write.option("mergeSchema", "true").format("delta").mode("append").save(delta_table_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 4. Optimizing Cluster Usage and Configuration
# MAGIC
# MAGIC Choosing the right cluster configuration is critical for managing costs and ensuring optimal performance.
# MAGIC
# MAGIC ### Cluster Sizing and Autoscaling
# MAGIC
# MAGIC 1. **Use Autoscaling**:
# MAGIC    - Configure autoscaling to automatically adjust the number of nodes based on workload demand, reducing idle time and minimizing costs.
# MAGIC
# MAGIC 2. **Right-Sizing the Cluster**:
# MAGIC    - Match cluster instance types (e.g., memory-optimized or compute-optimized) to your workload requirements.
# MAGIC    - For large jobs, increase the instance type’s memory and CPU rather than adding excessive nodes to avoid high shuffle costs.
# MAGIC
# MAGIC 3. **Optimize Spark Configurations**:
# MAGIC    - Tweak settings like `spark.sql.shuffle.partitions` to match the data size and cluster capacity.
# MAGIC    - Lower the number of partitions for smaller clusters to reduce shuffle costs.
# MAGIC
# MAGIC ### Spot Instances for Cost Savings
# MAGIC
# MAGIC Using **Spot Instances** (on AWS) or **Preemptible VMs** (on GCP) for non-critical workloads can provide significant cost savings. They may be terminated at any time but are much cheaper than on-demand instances.
# MAGIC
# MAGIC
# MAGIC ### Instance Pools for Efficient Start-Up
# MAGIC
# MAGIC Instance pools in Databricks allow clusters to reuse idle instances, reducing the time and cost associated with cluster start-up, especially for frequent short-lived jobs.
# MAGIC
# MAGIC - Create an instance pool and assign your job cluster to use it.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 5. Job Scheduling and Automation
# MAGIC
# MAGIC Efficient scheduling of jobs reduces idle compute time and optimizes resource usage.
# MAGIC
# MAGIC ### Schedule Jobs During Off-Peak Hours
# MAGIC
# MAGIC Running non-urgent jobs during off-peak hours can reduce costs by taking advantage of lower rates or freeing up resources for more critical workloads.
# MAGIC
# MAGIC ### Batch Similar Tasks
# MAGIC
# MAGIC Batching smaller tasks into a single job reduces overhead associated with cluster initialization and termination. For instance, group data transformations and aggregations in a single scheduled job.
# MAGIC
# MAGIC ### Auto-Termination
# MAGIC
# MAGIC Enable auto-termination for clusters that don’t need to stay active between job runs to avoid incurring costs for idle clusters.
# MAGIC
# MAGIC ```json
# MAGIC "cluster_info": {
# MAGIC     "autotermination_minutes": 30
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 6. Monitoring and Alerting for Cost Management
# MAGIC
# MAGIC Databricks provides various monitoring and alerting tools to help you keep track of costs and identify inefficiencies.
# MAGIC
# MAGIC ### Monitor with Databricks Cluster Metrics
# MAGIC
# MAGIC Use the **Cluster Metrics** UI in Databricks to monitor CPU, memory, and disk usage. This helps you detect under-utilized resources and adjust cluster sizing accordingly.
# MAGIC
# MAGIC ### Set Up Cost Alerts
# MAGIC
# MAGIC 1. **Cloud Provider Cost Alerts**:
# MAGIC    - Configure cost alerts directly in AWS, Azure, or GCP to notify you when resource usage or costs exceed defined thresholds.
# MAGIC
# MAGIC 2. **Databricks Audit Logs**:
# MAGIC    - Enable and review Databricks audit logs to identify unused resources, long-running queries, and clusters that can be optimized.
# MAGIC
# MAGIC ### Optimize Long-Running Jobs
# MAGIC
# MAGIC For long-running or streaming jobs, monitor real-time performance metrics and adjust settings for optimal performance. Using checkpoints in streaming pipelines can help reduce recovery time and associated costs.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 7. Best Practices for Cost and Performance Optimization
# MAGIC
# MAGIC 1. **Use Delta Lake for Storage**:
# MAGIC    - Delta Lake’s ACID compliance and support for efficient storage management (e.g., compaction, Z-ordering) make it ideal for reducing read/write costs and improving performance.
# MAGIC
# MAGIC 2. **Regularly Compact and Optimize Data**:
# MAGIC    - Periodically compact data in Delta tables and use Z-ordering on commonly filtered columns to optimize query performance.
# MAGIC
# MAGIC 3. **Set Up Proper Cluster Policies**:
# MAGIC    - Define cluster policies to limit cluster types, node counts, and resource configurations. This ensures consistency and avoids excessive costs.
# MAGIC
# MAGIC 4. **Optimize Data Partitioning**:
# MAGIC    - Partition data based on query patterns to minimize scan costs and improve parallel processing efficiency.
# MAGIC
# MAGIC 5. **Leverage Databricks Jobs for Automation**:
# MAGIC    - Use Databricks Jobs for scheduling and orchestrating data pipelines, ensuring tasks are run only as needed.
# MAGIC
# MAGIC 6. **Use Spot Instances and Instance Pools**:
# MAGIC    - For transient and non-critical workloads, use spot instances for cost savings, and leverage instance pools for quicker start times.
# MAGIC
# MAGIC 7. **Regularly Review Performance Metrics**:
# MAGIC    - Use Spark UI, Delta Lake metrics, and Databricks Jobs monitoring tools to continuously review and adjust your pipeline for optimal performance.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 8. Summary
# MAGIC
# MAGIC This document provides comprehensive techniques for **Optimizing Cost and Performance of Data Pipelines in Databricks**. 
# MAGIC
# MAGIC 1. **Spark Optimizations**: Partitioning, caching, and Adaptive Query Execution.
# MAGIC 2. **Delta Lake Optimizations**: Compaction, Z-ordering, and schema evolution for efficient data handling.
# MAGIC 3. **Cluster Configuration**: Autoscaling, right-sizing, and using spot instances to manage costs.
# MAGIC 4. **Job Scheduling and Automation**: Efficiently schedule and terminate jobs to reduce idle costs.
# MAGIC 5. **Monitoring and Alerting**: Track costs and optimize resource usage with Databricks and cloud provider tools.
# MAGIC
# MAGIC By applying these techniques, you can optimize both the cost and performance of your Databricks data pipelines, ensuring efficient and cost-effective data processing. Let me know if you need additional guidance or