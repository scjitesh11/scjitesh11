# Databricks notebook source
# MAGIC %md
# MAGIC # Building a Real-Time Data Pipeline Using Kafka and Delta Live Tables
# MAGIC
# MAGIC ## 1. Introduction to Real-Time Data Pipelines with Kafka and DLT
# MAGIC
# MAGIC Building a real-time data pipeline using **Apache Kafka** and **Delta Live Tables (DLT)** enables efficient, continuous data ingestion, transformation, and storage. Kafka serves as the data ingestion layer, while DLT provides transformation, quality control, and storage management using Delta Lake.
# MAGIC
# MAGIC ### Key Benefits
# MAGIC - **Scalable Ingestion**: Kafka handles large data streams in real-time.
# MAGIC - **Automated Transformations**: Delta Live Tables simplify the transformation and cleaning of real-time data.
# MAGIC - **Reliable Storage**: Delta Lake provides ACID transactions, schema enforcement, and time-travel for robust data storage.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Setup and Prerequisites
# MAGIC
# MAGIC 1. **Apache Kafka Cluster**: A Kafka cluster with topics created for the data stream.
# MAGIC 2. **Databricks Workspace**: Access to a Databricks workspace with Delta Live Tables enabled.
# MAGIC 3. **Library Dependencies**: Ensure Kafka libraries are installed on the Databricks cluster to enable connectivity.
# MAGIC
# MAGIC ### Kafka Cluster Connection Details
# MAGIC
# MAGIC In this guide, we’ll use the following Kafka connection details:
# MAGIC - **Kafka Bootstrap Servers**: `kafka-broker1:9092,kafka-broker2:9092`
# MAGIC - **Topic Name**: `retail_transactions`
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 3. Step 1: Create Kafka Topics and Simulate Data
# MAGIC
# MAGIC To set up a real-time pipeline, start by creating Kafka topics and simulating real-time data streaming.
# MAGIC
# MAGIC ### 3.1 Create a Kafka Topic
# MAGIC
# MAGIC Create a Kafka topic named `retail_transactions` in your Kafka environment.

# COMMAND ----------

# MAGIC %%bash
# MAGIC # Command to create Kafka topic
# MAGIC kafka-topics --create --topic retail_transactions --bootstrap-server kafka-broker1:9092,kafka-broker2:9092 --partitions 3 --replication-factor 2

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3.2 Simulate Streaming Data to Kafka
# MAGIC
# MAGIC For testing purposes, write a script or use a Kafka producer to send JSON messages to the `retail_transactions` topic.
# MAGIC
# MAGIC Example JSON message structure:
# MAGIC
# MAGIC ```json
# MAGIC {
# MAGIC   "transaction_id": "TX12345",
# MAGIC   "customer_id": 123,
# MAGIC   "transaction_amount": 200.50,
# MAGIC   "transaction_date": "2023-11-10T14:30:00",
# MAGIC   "country": "US"
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 4. Step 2: Configure Databricks Cluster and Library Dependencies
# MAGIC
# MAGIC 1. **Navigate to the Databricks Cluster**: In your Databricks workspace, go to **Clusters** and select the cluster you will use.
# MAGIC 2. **Install Libraries**:
# MAGIC    - Add the **Kafka client** library to the cluster. Use `org.apache.spark:spark-sql-kafka-0-10_2.12:<spark-version>` (e.g., for Spark 3.1, use `org.apache.spark:spark-sql-kafka-0-10_2.12:3.1.1`).
# MAGIC 3. **Set Up Kafka Configuration**:
# MAGIC    - Ensure you have the necessary Kafka configuration and permissions to connect to the cluster.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 5. Step 3: Creating the Delta Live Tables Pipeline
# MAGIC
# MAGIC Create a new DLT notebook in Databricks where we will define data ingestion, transformations, and quality checks.
# MAGIC
# MAGIC ### Data Ingestion from Kafka
# MAGIC
# MAGIC 1. **Define Kafka Ingestion Layer**: Use Delta Live Tables to create a streaming table that ingests data from the `retail_transactions` Kafka topic.

# COMMAND ----------

import dlt
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

# Define schema for transaction data
transaction_schema = StructType([
    StructField("transaction_id", StringType(), True),
    StructField("customer_id", IntegerType(), True),
    StructField("transaction_amount", DoubleType(), True),
    StructField("transaction_date", TimestampType(), True),
    StructField("country", StringType(), True)
])

@dlt.table(
    name="raw_transactions",
    comment="Ingest raw transaction data from Kafka"
)
def raw_transactions():
    return (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", "kafka-broker1:9092,kafka-broker2:9092")
        .option("subscribe", "retail_transactions")
        .option("startingOffsets", "latest")
        .load()
        .selectExpr("CAST(value AS STRING) as json")
        .select(from_json(col("json"), transaction_schema).alias("data"))
        .select("data.*")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### Data Transformation and Quality Checks
# MAGIC
# MAGIC 2. **Define Transformation Layer**: Clean and standardize the ingested data, including filtering out any rows with null or invalid values.

# COMMAND ----------

@dlt.table(
    name="cleaned_transactions",
    comment="Cleaned transaction data with standardized schema"
)
def cleaned_transactions():
    return (
        dlt.read("raw_transactions")
        .filter(col("transaction_amount").isNotNull() & (col("transaction_amount") > 0))
        .filter(col("customer_id").isNotNull() & (col("customer_id") > 0))
        .filter(col("transaction_date").isNotNull())
    )

# COMMAND ----------

# MAGIC %md
# MAGIC 3. **Define Data Quality Expectations**: Add data quality checks to ensure data integrity.

# COMMAND ----------

@dlt.table(
    name="validated_transactions",
    comment="Validated transaction data with data quality checks"
)
@dlt.expect("valid_amount", "transaction_amount > 0")
@dlt.expect("valid_customer_id", "customer_id IS NOT NULL AND customer_id > 0")
def validated_transactions():
    return dlt.read("cleaned_transactions")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### Data Aggregation
# MAGIC
# MAGIC 4. **Define Aggregation Layer**: Aggregate data to calculate total transaction amounts by customer.

# COMMAND ----------

@dlt.table(
    name="customer_transaction_totals",
    comment="Aggregated total transaction amount per customer"
)
def customer_transaction_totals():
    return (
        dlt.read("validated_transactions")
        .groupBy("customer_id")
        .agg({"transaction_amount": "sum"})
        .withColumnRenamed("sum(transaction_amount)", "total_transaction_amount")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 6. Step 4: Running and Monitoring the Real-Time Pipeline
# MAGIC
# MAGIC 1. **Go to Delta Live Tables in Databricks**:
# MAGIC    - Navigate to **Workflows > Delta Live Tables** and create a new pipeline.
# MAGIC    
# MAGIC 2. **Configure Pipeline Settings**:
# MAGIC    - Set the notebook path to your DLT notebook (`/Workspace/DeltaLiveTables/KafkaRealTimePipeline`).
# MAGIC    - Set the **Pipeline Mode** to **Continuous** for real-time data processing.
# MAGIC    - Specify the **Storage Location** for pipeline metadata (e.g., `dbfs:/pipelines/kafka_realtime_pipeline/`).
# MAGIC
# MAGIC 3. **Start the Pipeline**:
# MAGIC    - Start the pipeline to begin real-time data ingestion from Kafka and observe the processing of data in each table.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 7. Step 5: Configuring Pipeline Scheduling and Alerts
# MAGIC
# MAGIC Although the pipeline is running in **Continuous** mode for real-time processing, it’s beneficial to configure alerts to monitor pipeline health.
# MAGIC
# MAGIC ### Configuring Alerts
# MAGIC
# MAGIC 1. **Navigate to the DLT Pipeline UI**: In the Delta Live Tables interface, go to the pipeline you created.
# MAGIC 2. **Set Up Notifications**:
# MAGIC    - Configure notifications for when the pipeline fails, encounters data quality issues, or completes successfully.
# MAGIC 3. **Monitor Pipeline Health**:
# MAGIC    - The DLT UI provides real-time metrics on processing latency, throughput, and data quality checks, enabling you to quickly identify and resolve any issues.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 8. Summary
# MAGIC
# MAGIC In this guide, we covered **Building a Real-Time Data Pipeline Using Kafka and Delta Live Tables** in Databricks. Here’s a summary of each step:
# MAGIC
# MAGIC 1. **Kafka Topic Creation and Data Simulation**: Created a Kafka topic and simulated real-time data for ingestion.
# MAGIC 2. **Databricks Cluster Configuration**: Configured Kafka libraries on the Databricks cluster.
# MAGIC 3. **Delta Live Tables Pipeline Setup**: Defined ingestion, transformation, and aggregation layers in a DLT notebook.
# MAGIC 4. **Pipeline Execution and Monitoring**: Configured and ran the DLT pipeline in Continuous mode, with real-time