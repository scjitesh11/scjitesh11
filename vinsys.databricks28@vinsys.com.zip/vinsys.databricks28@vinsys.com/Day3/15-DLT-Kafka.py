# Databricks notebook source
import dlt
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

# Define schema for transaction data
transaction_schema = StructType([
    StructField("transaction_id", StringType(), True),
    StructField("customer_id", IntegerType(), True),
    StructField("transaction_amount", DoubleType(), True),
    StructField("transaction_date", TimestampType(), True),
    StructField("country", StringType(), True)
])

@dlt.table(
    name="raw_transactions",
    comment="Ingest raw transaction data from Kafka"
)
def raw_transactions():
    return (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", "52.178.146.226:9092,52.178.146.226:9093,52.178.146.226:9094")
        .option("subscribe", "retail_transactions")
        .option("startingOffsets", "latest")
        .load()
        .selectExpr("CAST(value AS STRING) as json")
        .select(from_json(col("json"), transaction_schema).alias("data"))
        .select("data.*")
    )

# COMMAND ----------

@dlt.table(
    name="cleaned_transactions",
    comment="Cleaned transaction data with standardized schema"
)
def cleaned_transactions():
    return (
        dlt.read("raw_transactions")
        .filter(col("transaction_amount").isNotNull() & (col("transaction_amount") > 0))
        .filter(col("customer_id").isNotNull() & (col("customer_id") > 0))
        .filter(col("transaction_date").isNotNull())
    )

# COMMAND ----------

@dlt.table(
    name="validated_transactions",
    comment="Validated transaction data with data quality checks"
)
@dlt.expect("valid_amount", "transaction_amount > 0")
@dlt.expect("valid_customer_id", "customer_id IS NOT NULL AND customer_id > 0")
def validated_transactions():
    return dlt.read("cleaned_transactions")

# COMMAND ----------

@dlt.table(
    name="customer_transaction_totals",
    comment="Aggregated total transaction amount per customer"
)
def customer_transaction_totals():
    return (
        dlt.read("validated_transactions")
        .groupBy("customer_id")
        .agg({"transaction_amount": "sum"})
        .withColumnRenamed("sum(transaction_amount)", "total_transaction_amount")
    )