# Databricks notebook source
# Ingest Bank Data from S3
s3_data_path = "/mnt/s3dataread/bank-customers.csv"
bank_df = spark.read.csv(s3_data_path, header=True, inferSchema=True)
bank_df.write.format("delta").mode("overwrite").save("/mnt/s3dataread/delta/bank_data")
print("Data ingestion completed.")