# Databricks notebook source
# MAGIC %md
# MAGIC # Multi-Hop Architecture and Stream Processing with Kafka in Databricks
# MAGIC
# MAGIC ## 1. Introduction to Multi-Hop Architecture
# MAGIC
# MAGIC **Multi-Hop Architecture** (or **medallion architecture**) is a layered approach to data processing, where data flows through different stages (Bronze, Silver, and Gold) to ensure data quality, accuracy, and performance. It is widely used in data lake architectures to gradually refine data, making it more useful and accurate as it moves from raw ingestion to final analytics.
# MAGIC
# MAGIC In a **multi-hop streaming architecture**, data flows continuously through each layer, allowing for real-time insights and minimizing latency from data ingestion to reporting.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Multi-Hop Architecture Stages
# MAGIC
# MAGIC ### Bronze Layer (Raw Data)
# MAGIC
# MAGIC - **Purpose**: Stores raw, unprocessed data from the source in its original format. This layer acts as the immutable log for all ingested data.
# MAGIC - **Typical Operations**: Simple ingestion and storage without transformations.
# MAGIC - **Example Data**: Raw Kafka messages containing event data or transactional logs.
# MAGIC
# MAGIC ### Silver Layer (Cleaned and Enriched Data)
# MAGIC
# MAGIC - **Purpose**: Cleans and enriches data from the Bronze layer, removing duplicates, handling missing values, and transforming data into a more structured format.
# MAGIC - **Typical Operations**: Deduplication, data cleaning, and enrichment.
# MAGIC - **Example Data**: Parsed JSON or flattened data with basic validation applied.
# MAGIC
# MAGIC ### Gold Layer (Aggregated and Curated Data)
# MAGIC
# MAGIC - **Purpose**: Contains the final, curated data used for analytics and reporting. This layer is optimized for performance, containing aggregated and fully refined data.
# MAGIC - **Typical Operations**: Aggregations, summarizations, and feature engineering.
# MAGIC - **Example Data**: Aggregated metrics for business reporting, such as total sales per region.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 3. Setting Up Kafka and Databricks for Stream Processing
# MAGIC
# MAGIC ### Prerequisites
# MAGIC
# MAGIC 1. **Kafka Cluster**: Set up an Apache Kafka cluster and create a topic to receive data. The topic could be, for example, `retail_transactions`.
# MAGIC 2. **Databricks Cluster**: Configure a Databricks cluster with Kafka libraries installed.
# MAGIC
# MAGIC 3. **Cluster Permissions**: Ensure Databricks has network permissions to connect to the Kafka cluster.
# MAGIC
# MAGIC ### Kafka Connection Details
# MAGIC - **Kafka Bootstrap Servers**: Addresses of Kafka brokers, e.g., `kafka-broker1:9092,kafka-broker2:9092`
# MAGIC - **Kafka Topic**: Name of the Kafka topic, e.g., `retail_transactions`
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 4. Implementing Multi-Hop Architecture with Kafka and Delta Lake
# MAGIC
# MAGIC This section provides step-by-step instructions for implementing a multi-hop architecture to process streaming data from Kafka in Databricks.
# MAGIC
# MAGIC ### Step 1: Ingesting Data from Kafka to the Bronze Layer
# MAGIC
# MAGIC Ingest raw data from Kafka into the Bronze layer in Delta Lake format, retaining the original structure of the data.

# COMMAND ----------

import dlt
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

# Define the schema for raw transaction data
transaction_schema = StructType([
    StructField("transaction_id", StringType(), True),
    StructField("customer_id", IntegerType(), True),
    StructField("transaction_amount", DoubleType(), True),
    StructField("transaction_date", TimestampType(), True),
    StructField("country", StringType(), True)
])

@dlt.table(
    name="bronze_transactions",
    comment="Raw data ingestion from Kafka to Bronze layer"
)
def bronze_transactions():
    return (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", "kafka-broker1:9092,kafka-broker2:9092")
        .option("subscribe", "retail_transactions")
        .option("startingOffsets", "latest")
        .load()
        .selectExpr("CAST(value AS STRING) as json")
        .select(from_json(col("json"), transaction_schema).alias("data"))
        .select("data.*")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Processing and Storing Data in the Silver Layer
# MAGIC
# MAGIC The Silver layer cleans and validates the data by removing duplicates, handling null values, and enforcing data quality checks.

# COMMAND ----------

@dlt.table(
    name="silver_transactions",
    comment="Cleaned and enriched transactions data in Silver layer"
)
@dlt.expect("valid_transaction_amount", "transaction_amount > 0")
@dlt.expect("valid_customer_id", "customer_id IS NOT NULL AND customer_id > 0")
def silver_transactions():
    return (
        dlt.read("bronze_transactions")
        .dropDuplicates(["transaction_id"])
        .filter(col("transaction_date").isNotNull())
        .withColumn("year", col("transaction_date").year)
        .withColumn("month", col("transaction_date").month)
    )

# COMMAND ----------

# MAGIC %md
# MAGIC **Explanation**:
# MAGIC - **`dlt.expect`**: Defines data quality checks for `transaction_amount` and `customer_id`.
# MAGIC - **Data Cleaning**: Removes duplicates and null values in key columns.
# MAGIC
# MAGIC ### Step 3: Aggregating Data in the Gold Layer
# MAGIC
# MAGIC The Gold layer aggregates and curates the data, creating summary views or KPIs. In this example, it calculates the total transaction amount by country.

# COMMAND ----------

@dlt.table(
    name="gold_country_sales",
    comment="Aggregated total sales by country in Gold layer"
)
def gold_country_sales():
    silver_transactions_df = dlt.read("silver_transactions")
    
    # Cache the dataframe
    silver_transactions_df = silver_transactions_df.cache()

    return (
        silver_transactions_df
        .groupBy("country")
        .agg({"transaction_amount": "sum"})
        .withColumnRenamed("sum(transaction_amount)", "total_sales")
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## 5. Monitoring and Optimizing Stream Processing
# MAGIC
# MAGIC ### Monitoring Streaming Pipeline
# MAGIC
# MAGIC 1. **Delta Live Tables Monitoring UI**:
# MAGIC    - In the DLT UI, track real-time data ingestion and processing metrics for each layer (Bronze, Silver, Gold).
# MAGIC    - Use metrics like throughput and latency to ensure data is processed within expected timeframes.
# MAGIC    
# MAGIC 2. **Spark UI**:
# MAGIC    - Access the Spark UI to monitor job and stage metrics, task durations, and any shuffle operations.
# MAGIC    - Use the SQL tab to diagnose slow transformations or high shuffle operations, which can slow down the pipeline.
# MAGIC
# MAGIC ### Optimization Techniques
# MAGIC
# MAGIC 1. **Data Compaction (Optimize Command)**:
# MAGIC    - In Delta Lake, compact small files periodically to improve read performance, especially in the Bronze and Silver layers.
# MAGIC
# MAGIC     ```python
# MAGIC     from delta.tables import DeltaTable
# MAGIC
# MAGIC     bronze_table_path = "/mnt/delta/bronze_transactions"
# MAGIC     bronze_table = DeltaTable.forPath(spark, bronze_table_path)
# MAGIC     bronze_table.optimize().executeCompaction()
# MAGIC     ```
# MAGIC
# MAGIC 2. **Z-Ordering**:
# MAGIC    - Apply Z-ordering in the Gold layer to improve query performance on frequently queried columns, such as `country`.
# MAGIC
# MAGIC     ```python
# MAGIC     gold_table = DeltaTable.forPath(spark, "/mnt/delta/gold_country_sales")
# MAGIC     gold_table.optimize().executeZOrderBy("country")
# MAGIC     ```
# MAGIC
# MAGIC 3. **Caching**:
# MAGIC    - Cache DataFrames in memory if they are reused in downstream transformations.
# MAGIC
# MAGIC     ```python
# MAGIC     silver_transactions.cache()
# MAGIC     ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 6. Kaka Commands
# MAGIC ```
# MAGIC kafka-topics --create --topic retail_transactions --bootstrap-server kafka-broker1:9092,kafka-broker2:9092 --partitions 3 --replication-factor 2
# MAGIC ```
# MAGIC
# MAGIC ```
# MAGIC kafka-console-producer --topic retail_transactions --bootstrap-server kafka-broker1:9092,kafka-broker2:9092
# MAGIC
# MAGIC {"transaction_id": "TX1001", "customer_id": 101, "transaction_amount": 150.75, "transaction_date": "2023-11-10T10:30:00", "country": "US"}
# MAGIC {"transaction_id": "TX1002", "customer_id": 102, "transaction_amount": 245.00, "transaction_date": "2023-11-10T11:00:00", "country": "CA"}
# MAGIC {"transaction_id": "TX1003", "customer_id": 103, "transaction_amount": 320.50, "transaction_date": "2023-11-10T12:15:00", "country": "GB"}
# MAGIC {"transaction_id": "TX1004", "customer_id": 104, "transaction_amount": 99.99, "transaction_date": "2023-11-10T13:45:00", "country": "DE"}
# MAGIC {"transaction_id": "TX1005", "customer_id": 105, "transaction_amount": 225.00, "transaction_date": "2023-11-10T14:20:00", "country": "US"}
# MAGIC ```
# MAGIC
# MAGIC ```
# MAGIC for i in {1..10}
# MAGIC do
# MAGIC   echo "{\"transaction_id\": \"TX$i\", \"customer_id\": $((100 + $i)), \"transaction_amount\": $((RANDOM % 500 + 50)).99, \"transaction_date\": \"2023-11-10T$((RANDOM % 24)):$(printf %02d $((RANDOM % 60))):00\", \"country\": \"$(shuf -n1 -e US CA GB DE)\"}" | \
# MAGIC   kafka-console-producer --topic retail_transactions --bootstrap-server kafka-broker1:9092,kafka-broker2:9092
# MAGIC   sleep 1
# MAGIC done
# MAGIC ```
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Best Practices for Multi-Hop Architecture
# MAGIC
# MAGIC 1. **Schema Enforcement**: Enforce schema at each hop to maintain data consistency and manage evolving schemas in streaming data.
# MAGIC 2. **Data Quality Checks**: Use `dlt.expect` to enforce data quality rules at each layer, especially in the Silver and Gold layers.
# MAGIC 3. **Checkpointing**: Ensure all streaming queries have a checkpoint location to allow for fault tolerance and accurate streaming state management.
# MAGIC 4. **Optimize File Sizes**: Regularly compact Delta Lake files in Bronze and Silver layers to optimize performance.
# MAGIC 5. **Cost Control**: Use instance pools, autoscaling, and cluster policies to manage costs, especially for long-running streaming jobs.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 8. Summary
# MAGIC
# MAGIC In this document, we covered the **Multi-Hop Architecture and Stream Processing with Kafka** in Databricks:
# MAGIC 1. **Multi-Hop Architecture Layers**: Explained the Bronze, Silver, and Gold layers for progressive data refinement.
# MAGIC 2. **Ingesting Data from Kafka**: Used Delta Live Tables to ingest raw data from Kafka and store it in Delta Lake.
# MAGIC 3. **Data Transformation and Quality Checks**: Implemented data cleaning, enrichment, and validation in the