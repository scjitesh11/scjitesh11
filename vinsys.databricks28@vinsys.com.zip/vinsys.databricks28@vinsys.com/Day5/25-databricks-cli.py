# Databricks notebook source
# MAGIC %md
# MAGIC # **Databricks CLI: Setup and Automation**
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## **1. Overview**
# MAGIC
# MAGIC The Databricks CLI (Command Line Interface) is a powerful tool for interacting with Databricks workspaces programmatically. It allows users to manage clusters, jobs, notebooks, secrets, and more via command-line commands or scripts.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## **2. Installation and Setup**
# MAGIC
# MAGIC ### **Step 1: Prerequisites**
# MAGIC 1. **Python Installed**:
# MAGIC    - Ensure Python 3.6 or later is installed on your system.
# MAGIC    - Verify Python version:
# MAGIC      ```bash
# MAGIC      python --version
# MAGIC      ```
# MAGIC
# MAGIC 2. **Databricks Workspace Access**:
# MAGIC    - You need access to a Databricks workspace and an authentication token.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Step 2: Install Databricks CLI**
# MAGIC
# MAGIC 1. Install Databricks CLI using `pip`:
# MAGIC    ```bash
# MAGIC    pip install databricks-cli
# MAGIC    ```
# MAGIC
# MAGIC 2. Verify installation:
# MAGIC    ```bash
# MAGIC    databricks --version
# MAGIC    ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Step 3: Configure Databricks CLI**
# MAGIC
# MAGIC 1. Run the Databricks CLI configuration command:
# MAGIC    ```bash
# MAGIC    databricks configure --token
# MAGIC    ```
# MAGIC
# MAGIC 2. Provide the following details when prompted:
# MAGIC    - **Databricks Host**: Your Databricks workspace URL (e.g., `https://<databricks-instance>.cloud.databricks.com`).
# MAGIC    - **Token**: Your personal access token from Databricks.
# MAGIC
# MAGIC 3. Confirm the configuration:
# MAGIC    ```bash
# MAGIC    cat ~/.databrickscfg
# MAGIC    ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## **3. Common Databricks CLI Commands**
# MAGIC
# MAGIC Here are key Databricks CLI commands categorized by functionality.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **3.1 Workspace Management**
# MAGIC
# MAGIC #### **Upload Notebooks**
# MAGIC
# MAGIC 1. Upload a local notebook to Databricks:
# MAGIC    ```bash
# MAGIC    databricks workspace import \
# MAGIC        --overwrite \
# MAGIC        ./local-notebook.py \
# MAGIC        /Users/your-username/remote-notebook
# MAGIC    ```
# MAGIC
# MAGIC 2. Upload all notebooks from a local directory:
# MAGIC    ```bash
# MAGIC    databricks workspace import_dir \
# MAGIC        ./local-directory \
# MAGIC        /Users/your-username/remote-directory
# MAGIC    ```
# MAGIC
# MAGIC #### **Download Notebooks**
# MAGIC
# MAGIC 1. Download a notebook from Databricks:
# MAGIC    ```bash
# MAGIC    databricks workspace export \
# MAGIC        /Users/your-username/remote-notebook \
# MAGIC        ./local-notebook.py
# MAGIC    ```
# MAGIC
# MAGIC 2. Download all notebooks from a directory:
# MAGIC    ```bash
# MAGIC    databricks workspace export_dir \
# MAGIC        /Users/your-username/remote-directory \
# MAGIC        ./local-directory
# MAGIC    ```
# MAGIC
# MAGIC #### **List Workspace Items**
# MAGIC
# MAGIC List all items in a workspace directory:

# COMMAND ----------

databricks workspace ls /Users/your-username/

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **3.2 Cluster Management**
# MAGIC
# MAGIC #### **List Clusters**
# MAGIC Retrieve a list of all clusters:

# COMMAND ----------

databricks clusters list

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Create a Cluster**
# MAGIC Create a new cluster using a JSON configuration file:

# COMMAND ----------

databricks clusters create --json-file cluster-config.json

# COMMAND ----------

# MAGIC %md
# MAGIC Example `cluster-config.json`:
# MAGIC ```json
# MAGIC {
# MAGIC   "cluster_name": "example-cluster",
# MAGIC   "spark_version": "10.4.x-scala2.12",
# MAGIC   "node_type_id": "i3.xlarge",
# MAGIC   "num_workers": 2
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC #### **Terminate a Cluster**
# MAGIC Terminate a cluster by its cluster ID:

# COMMAND ----------

databricks clusters delete --cluster-id <cluster-id>

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **3.3 Job Management**
# MAGIC
# MAGIC #### **List Jobs**
# MAGIC Retrieve a list of all jobs:

# COMMAND ----------

databricks jobs list

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Run a Job**
# MAGIC Trigger a job run by its job ID:

# COMMAND ----------

databricks jobs run-now --job-id <job-id>

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Create a Job**
# MAGIC Create a new job using a JSON configuration file:

# COMMAND ----------

databricks jobs create --json-file job-config.json

# COMMAND ----------

# MAGIC %md
# MAGIC Example `job-config.json`:
# MAGIC ```json
# MAGIC {
# MAGIC   "name": "example-job",
# MAGIC   "new_cluster": {
# MAGIC     "spark_version": "10.4.x-scala2.12",
# MAGIC     "node_type_id": "i3.xlarge",
# MAGIC     "num_workers": 1
# MAGIC   },
# MAGIC   "notebook_task": {
# MAGIC     "notebook_path": "/Users/your-username/example-notebook"
# MAGIC   }
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC #### **Delete a Job**
# MAGIC Remove a job by its job ID:

# COMMAND ----------

databricks jobs delete --job-id <job-id>

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **3.4 Secret Management**
# MAGIC
# MAGIC #### **Create a Secret Scope**
# MAGIC Create a new secret scope:

# COMMAND ----------

databricks secrets create-scope --scope <scope-name>

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Add a Secret**
# MAGIC Store a secret in a scope:

# COMMAND ----------

databricks secrets put --scope <scope-name> --key <key-name>

# COMMAND ----------

# MAGIC %md
# MAGIC #### **List Secret Scopes**
# MAGIC Retrieve all available secret scopes:

# COMMAND ----------

databricks secrets list-scopes

# COMMAND ----------

# MAGIC %md
# MAGIC #### **List Secrets in a Scope**
# MAGIC View secrets within a scope:

# COMMAND ----------

databricks secrets list --scope <scope-name>

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **3.5 File Management**
# MAGIC
# MAGIC #### **Upload Files to DBFS**
# MAGIC Upload a local file to Databricks File System (DBFS):

# COMMAND ----------

databricks fs cp local-file.txt dbfs:/remote-folder/

# COMMAND ----------

# MAGIC %md
# MAGIC #### **Download Files from DBFS**
# MAGIC Download a file from DBFS:

# COMMAND ----------

databricks fs cp dbfs:/remote-folder/remote-file.txt local-file.txt

# COMMAND ----------

# MAGIC %md
# MAGIC #### **List Files in DBFS**
# MAGIC List all files in a DBFS directory:

# COMMAND ----------

databricks fs ls dbfs:/remote-folder/

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ## **4. Automating Databricks CLI Commands**
# MAGIC
# MAGIC Databricks CLI can be automated using Python or Bash scripts.
# MAGIC
# MAGIC ### **Example: Python Script for Automation**

# COMMAND ----------

# MAGIC %%python
# MAGIC import os
# MAGIC import subprocess
# MAGIC
# MAGIC # Set Databricks CLI environment variables
# MAGIC os.environ["DATABRICKS_HOST"] = "https://<databricks-instance>.cloud.databricks.com"
# MAGIC os.environ["DATABRICKS_TOKEN"] = "<your-personal-access-token>"
# MAGIC
# MAGIC # Run a Databricks CLI command
# MAGIC def run_databricks_command(command):
# MAGIC     try:
# MAGIC         result = subprocess.run(command, shell=True, capture_output=True, text=True)
# MAGIC         print(result.stdout)
# MAGIC     except Exception as e:
# MAGIC         print(f"Error running command: {e}")
# MAGIC
# MAGIC # Example: List all clusters
# MAGIC run_databricks_command("databricks clusters list")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **Example: Bash Script for Automation**

# COMMAND ----------

#!/bin/bash

# Set Databricks CLI environment variables
export DATABRICKS_HOST="https://<databricks-instance>.cloud.databricks.com"
export DATABRICKS_TOKEN="<your-personal-access-token>"

# List all jobs
databricks jobs list