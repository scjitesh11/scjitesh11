# Databricks notebook source
# MAGIC %md
# MAGIC ### **Databricks and Airflow Integration**
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### **Objective**
# MAGIC Integrate Databricks and Airflow to:
# MAGIC 1. Automate Databricks job execution from Airflow.
# MAGIC 2. Schedule and monitor Databricks workflows using Airflow DAGs.
# MAGIC 3. Enable dynamic pipeline execution with parameterized Databricks jobs.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### **Prerequisites**
# MAGIC
# MAGIC 1. **Databricks Setup**:
# MAGIC    - A running **Databricks workspace**.
# MAGIC    - A **Databricks job** to execute (or create one).
# MAGIC    - Generate a **Databricks personal access token**:
# MAGIC      - Go to your Databricks account → **Settings** → **User Settings** → **Access Tokens** → **Generate Token**.
# MAGIC      - Save the token securely.
# MAGIC
# MAGIC 2. **Apache Airflow Setup**:
# MAGIC    - Airflow installed and configured (preferably via a virtual environment or Docker).
# MAGIC    - Ensure `apache-airflow-providers-databricks` is installed:
# MAGIC      ```bash
# MAGIC      pip install apache-airflow-providers-databricks
# MAGIC      ```
# MAGIC
# MAGIC 3. **Environment Variables**:
# MAGIC    - Set up the following environment variables or Airflow Connections:
# MAGIC      - **DATABRICKS_HOST**: Databricks workspace URL (e.g., `https://<databricks-instance>.cloud.databricks.com`).
# MAGIC      - **DATABRICKS_TOKEN**: The generated Databricks personal access token.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Steps for Integration**
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### **Step 1: Configure Airflow Connections**
# MAGIC
# MAGIC 1. Go to the Airflow **UI** → **Admin** → **Connections**.
# MAGIC 2. Create a new connection:
# MAGIC    - **Connection ID**: `databricks_default`
# MAGIC    - **Connection Type**: `Databricks`
# MAGIC    - **Host**: Your Databricks workspace URL (e.g., `https://<databricks-instance>.cloud.databricks.com`)
# MAGIC    - **Token**: Your Databricks personal access token.
# MAGIC 3. Save the connection.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### **Step 2: Create a Databricks Job**
# MAGIC
# MAGIC 1. Go to the **Databricks Workspace**.
# MAGIC 2. Navigate to **Jobs** → **Create Job**.
# MAGIC 3. Define the following:
# MAGIC    - **Job Name**: e.g., `example_job`
# MAGIC    - **Task**:
# MAGIC      - Choose a notebook or JAR file to run.
# MAGIC      - Specify any required parameters.
# MAGIC    - **Cluster Configuration**:
# MAGIC      - Attach an existing cluster or configure a new cluster.
# MAGIC 4. Save the job.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### **Step 3: Define Airflow DAG**
# MAGIC
# MAGIC 1. Create a Python file (e.g., `databricks_dag.py`) in your Airflow DAGs folder.
# MAGIC 2. Define a DAG that triggers the Databricks job using the `DatabricksSubmitRunOperator`.
# MAGIC
# MAGIC **Example Code**:

# COMMAND ----------

from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
from datetime import datetime

# Define default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
}

# Define the DAG
with DAG(
    'databricks_example_dag',
    default_args=default_args,
    description='An example DAG to run Databricks jobs',
    schedule_interval='@daily',  # Run daily
    start_date=datetime(2023, 11, 1),
    catchup=False,
) as dag:

    # Databricks job JSON payload
    databricks_job_config = {
        'existing_cluster_id': 'your-cluster-id',  # Replace with your cluster ID
        'notebook_task': {
            'notebook_path': '/Users/your-username/example-notebook',  # Replace with your notebook path
            'base_parameters': {'param1': 'value1'}  # Optional: Parameters for the notebook
        }
    }

    # Task: Trigger Databricks job
    run_databricks_job = DatabricksSubmitRunOperator(
        task_id='run_databricks_job',
        databricks_conn_id='databricks_default',  # Use the connection configured earlier
        json=databricks_job_config
    )

    run_databricks_job

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC #### **Step 4: Test the Integration**
# MAGIC
# MAGIC 1. **Trigger the DAG**:
# MAGIC    - Go to the Airflow UI → **DAGs**.
# MAGIC    - Locate and enable the `databricks_example_dag`.
# MAGIC    - Trigger a manual run to test.
# MAGIC
# MAGIC 2. **Monitor in Airflow**:
# MAGIC    - Check the task logs in the Airflow UI to confirm the Databricks job is triggered.
# MAGIC
# MAGIC 3. **Monitor in Databricks**:
# MAGIC    - Go to **Jobs** in Databricks and verify that the job has started.
# MAGIC    - Check job results and logs in the Databricks UI.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### **Step 5: Parameterize the Workflow**
# MAGIC
# MAGIC **Updated Example Code**:

# COMMAND ----------

from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
from airflow.operators.python import PythonOperator
from datetime import datetime

def get_dynamic_parameters():
    """Example function to generate dynamic parameters."""
    return {'param1': 'dynamic_value'}

with DAG(
    'databricks_parametrized_dag',
    default_args=default_args,
    description='A parametrized DAG for Databricks jobs',
    schedule_interval='@daily',
    start_date=datetime(2023, 11, 1),
    catchup=False,
) as dag:

    # Generate dynamic parameters
    generate_params = PythonOperator(
        task_id='generate_params',
        python_callable=get_dynamic_parameters,
    )

    # Use dynamic parameters in Databricks job
    databricks_job_config = {
        'existing_cluster_id': 'your-cluster-id',
        'notebook_task': {
            'notebook_path': '/Users/your-username/example-notebook',
        }
    }

    run_databricks_job = DatabricksSubmitRunOperator(
        task_id='run_databricks_job',
        databricks_conn_id='databricks_default',
        json=databricks_job_config,
        task_concurrency=5,  # Example of concurrency limit
        trigger_rule='all_success',
    )

    generate_params >> run_databricks_job

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **Step 6: Monitor and Troubleshoot**
# MAGIC
# MAGIC 1. **Airflow Logs**:
# MAGIC    - Review task logs in the Airflow UI for errors or API call details.
# MAGIC
# MAGIC 2. **Databricks Logs**:
# MAGIC    - Check the Databricks job logs (found in the **Jobs** UI) for details on execution and errors.
# MAGIC
# MAGIC 3. **Debug Common Errors**:
# MAGIC    - **Authentication Issues**:
# MAGIC      - Ensure the Airflow Databricks connection is correctly configured with valid host and token.
# MAGIC    - **Invalid Cluster ID**:
# MAGIC      - Verify that the cluster ID used in the `existing_cluster_id` field is correct.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Enhancements**
# MAGIC
# MAGIC 1. **Use Airflow Variables**:
# MAGIC    - Store reusable configurations (e.g., `databricks_job_config`) as Airflow variables.
# MAGIC
# MAGIC 2. **Event-Based Triggers**:
# MAGIC    - Use sensors (e.g., `S3KeySensor`) to trigger the DAG when new data is available in S3.
# MAGIC
# MAGIC 3. **Parallel Execution**:
# MAGIC    - Configure multiple tasks to run parallel Databricks jobs.
# MAGIC
# MAGIC ---