# Databricks notebook source
# MAGIC %md
# MAGIC ## **Project Overview**
# MAGIC
# MAGIC ### **Key Goals**
# MAGIC 1. Set up a data pipeline using:
# MAGIC    - Bronze, Silver, and Gold layers.
# MAGIC    - S3-mounted paths to store data.
# MAGIC    - Delta Lake for ACID-compliant storage.
# MAGIC    - Unity Catalog for governance and table management.
# MAGIC    - Delta Live Tables for real-time incremental updates.
# MAGIC
# MAGIC 2. Ensure:
# MAGIC    - No duplicate processing between DLT and earlier notebooks.
# MAGIC    - Proper optimizations (compaction, Z-ordering) and scheduled maintenance.
# MAGIC    - Incremental updates in the Gold layer using DLT.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Notebook Structure**
# MAGIC 1. **Notebook 1**: Setting Up S3 Mounts and Delta Lake Bronze Layer
# MAGIC    - Mount S3 buckets and create the Bronze layer.
# MAGIC    - Store raw data as Delta tables.
# MAGIC
# MAGIC 2. **Notebook 2**: Creating the Silver Layer
# MAGIC    - Clean and transform Bronze data into Silver tables.
# MAGIC    - Save as Delta tables and register in Unity Catalog.
# MAGIC
# MAGIC 3. **Notebook 3**: Creating the Gold Layer
# MAGIC    - Aggregate Silver data into Gold tables.
# MAGIC    - Save aggregated data as Delta tables.
# MAGIC
# MAGIC 4. **Notebook 4**: Delta Live Tables for Incremental Updates
# MAGIC    - Use DLT to update Silver and Gold layers incrementally.
# MAGIC
# MAGIC 5. **Notebook 5**: Optimizations and Maintenance
# MAGIC    - Optimize Delta tables (compaction, Z-ordering).
# MAGIC    - Schedule periodic maintenance tasks.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Implementation Details**
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### **Notebook 1: Setting Up S3 Mounts and Delta Lake Bronze Layer**
# MAGIC
# MAGIC #### Steps:
# MAGIC 1. Mount the S3 bucket.
# MAGIC 2. Load raw data from S3 and save it as a Delta table in the Bronze layer.
# MAGIC 3. Register the Bronze table in Unity Catalog.
# MAGIC
# MAGIC #### Code:

# COMMAND ----------

# Step 1: Mount S3 bucket
dbutils.fs.mount(
    source="s3a://your-bucket-name/retail-data/by-day/",
    mount_point="/mnt/s3data/retail-data/by-day",
    extra_configs={"fs.s3a.awsAccessKeyId": "<YOUR_ACCESS_KEY>",
                   "fs.s3a.awsSecretAccessKey": "<YOUR_SECRET_KEY>"}
)

# Step 2: Verify the mount
display(dbutils.fs.ls("/mnt/s3data/retail-data/by-day/"))

# Step 3: Load raw data and save as Bronze Delta table
raw_data = spark.read.format("csv").option("header", "true").load("/mnt/s3data/retail-data/by-day/")
bronze_path = "/mnt/s3data/bronze/retail_data"
raw_data.write.format("delta").mode("overwrite").save(bronze_path)

# Step 4: Register the Bronze table in Unity Catalog
spark.sql(f"""
CREATE TABLE IF NOT EXISTS retail_catalog.bronze.retail_data
USING DELTA
LOCATION '{bronze_path}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **Notebook 2: Creating the Silver Layer**
# MAGIC
# MAGIC #### Steps:
# MAGIC 1. Read Bronze Delta table.
# MAGIC 2. Clean and transform the data for the Silver layer.
# MAGIC 3. Save the transformed data as a Delta table and register it in Unity Catalog.
# MAGIC
# MAGIC #### Code:

# COMMAND ----------

# Step 1: Read Bronze data
bronze_df = spark.read.format("delta").load("/mnt/s3data/bronze/retail_data")

# Step 2: Transform Bronze data
from pyspark.sql.functions import col
silver_df = bronze_df.filter(col("transaction_amount").isNotNull()) \
                     .withColumnRenamed("transaction_date", "date") \
                     .withColumn("year", col("date").substr(1, 4))

# Step 3: Save Silver data as a Delta table
silver_path = "/mnt/s3data/silver/retail_data"
silver_df.write.format("delta").mode("overwrite").save(silver_path)

# Step 4: Register the Silver table in Unity Catalog
spark.sql(f"""
CREATE TABLE IF NOT EXISTS retail_catalog.silver.retail_data
USING DELTA
LOCATION '{silver_path}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **Notebook 3: Creating the Gold Layer**
# MAGIC
# MAGIC #### Steps:
# MAGIC 1. Read Silver Delta table.
# MAGIC 2. Aggregate Silver data for the Gold layer.
# MAGIC 3. Save the aggregated data as a Delta table and register it in Unity Catalog.
# MAGIC
# MAGIC #### Code:

# COMMAND ----------

# Step 1: Read Silver data
silver_df = spark.read.format("delta").load("/mnt/s3data/silver/retail_data")

# Step 2: Aggregate data for the Gold layer
gold_df = silver_df.groupBy("year", "region").sum("transaction_amount").alias("total_sales")

# Step 3: Save Gold data as a Delta table
gold_path = "/mnt/s3data/gold/retail_data"
gold_df.write.format("delta").mode("overwrite").save(gold_path)

# Step 4: Register the Gold table in Unity Catalog
spark.sql(f"""
CREATE TABLE IF NOT EXISTS retail_catalog.gold.retail_data
USING DELTA
LOCATION '{gold_path}'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **Notebook 4: Delta Live Tables for Incremental Updates**
# MAGIC
# MAGIC #### Steps:
# MAGIC 1. Use Bronze and Silver Delta tables as input for DLT.
# MAGIC 2. Update the Silver and Gold layers incrementally.
# MAGIC
# MAGIC #### Code:

# COMMAND ----------

import dlt
from pyspark.sql.functions import col, sum

# Bronze Table
@dlt.table
def bronze_retail_data():
    return spark.read.format("delta").load("/mnt/s3data/bronze/retail_data")

# Silver Table
@dlt.table
def silver_retail_data():
    return dlt.read("bronze_retail_data").filter(col("transaction_amount").isNotNull())

# Gold Table
@dlt.table
def gold_retail_data():
    existing_gold = spark.read.format("delta").load("/mnt/s3data/gold/retail_data")
    new_aggregates = (dlt.read("silver_retail_data")
                      .groupBy("region", "year")
                      .agg(sum("transaction_amount").alias("total_sales")))
    return existing_gold.union(new_aggregates)

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC
# MAGIC ### **Notebook 5: Optimizations and Maintenance**
# MAGIC
# MAGIC #### Steps:
# MAGIC 1. Compact small files in Delta tables.
# MAGIC 2. Apply Z-ordering for faster queries.
# MAGIC
# MAGIC #### Code:

# COMMAND ----------

from delta.tables import DeltaTable

# Optimize Bronze table
bronze_table = DeltaTable.forPath(spark, "/mnt/s3data/bronze/retail_data")
bronze_table.optimize().executeCompaction()

# Optimize Silver table
silver_table = DeltaTable.forPath(spark, "/mnt/s3data/silver/retail_data")
silver_table.optimize().executeCompaction()
silver_table.optimize().executeZOrderBy("date")

# Optimize Gold table
gold_table = DeltaTable.forPath(spark, "/mnt/s3data/gold/retail_data")
gold_table.optimize().executeCompaction()
gold_table.optimize().executeZOrderBy("region")