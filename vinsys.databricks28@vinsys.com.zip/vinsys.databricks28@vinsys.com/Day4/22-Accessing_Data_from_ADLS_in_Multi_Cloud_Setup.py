# Databricks notebook source
# MAGIC %md
# MAGIC # Pre-requisite
# MAGIC - We need to create a data lake account and also upload the input file to it
# MAGIC - Also need to create Service Principal and then allow access to SP on the Data Lake container which contains input files

# COMMAND ----------

# MAGIC %md
# MAGIC ## Mount Data from Data Lake

# COMMAND ----------

# Specify the Data Lake account details
adlsAccountName = "dldatabricks24"
adlsContainerName = "inputdata"
adlsFolderName = "data"

# COMMAND ----------

# Specify details of SP which will be used in this notebook to connect to the Data Lake account
applicationId = "edda4533-5172-4da4-aef6-b4b2dc446874"
authenticationKey = "PIj8Q~~3xE8-u5raD21iBIKARrkgHnolMyNJQaWe"
tenandId = "6bb2f9af-a0af-4c32-a5ec-5f7011d37551"

# COMMAND ----------

endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# COMMAND ----------

dbutils.fs.unmount("/mnt/data")
print("Source: ", source)
print("configs: ", configs)
print("endpoint: ", endpoint)

print("applicationId: ", applicationId)
print("authenticationKey: ", authenticationKey)
print("tenandId: ", tenandId)

print("adlsAccountName: ", adlsAccountName)
print("adlsContainerName: ", adlsContainerName)

print("adlsFolderName: ", adlsFolderName)

# COMMAND ----------

try:
  dbutils.fs.mount(source = source,mount_point = "/mnt/data",extra_configs = configs)
except Exception as e:
  print(e)
  #pass

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/data/

# COMMAND ----------

from pyspark.sql.functions import col, column, spark_partition_id

# COMMAND ----------

flightData2015="dbfs:/mnt/data/data/flight-data/csv/2010-summary.csv"
flightData2015="dbfs:/mnt/data/data/flight-data/csv"

# COMMAND ----------

flightDataDF2015 = spark\
.read\
.option("inferSchema", "true")\
.option("header", "true")\
.csv(flightData2015)

flightDataDF2015=flightDataDF2015.withColumn("partitionID", spark_partition_id())
flightDataDF2015.rdd.getNumPartitions()

# COMMAND ----------

flightDataDF2015.show(5000)

# COMMAND ----------

from pyspark.sql.functions import concat, collect_list, collect_set, concat_ws

#Notice that values in the column - DEST_COUNTRY_NAME are spead over all partitions. It will create shuffling issues if we do any operation based on DEST_COUNTRY_NAME
flightDataDF2015.groupBy("DEST_COUNTRY_NAME")\
.agg(concat_ws(", ", collect_set(flightDataDF2015.partitionID))).display(100)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Repartition based on a column using which we need to do group by

# COMMAND ----------

partition_count=flightDataDF2015.select('DEST_COUNTRY_NAME').distinct().count()
print(partition_count)

# COMMAND ----------

flightDataDF2015_rp=flightDataDF2015.repartition(partition_count, col("DEST_COUNTRY_NAME")).withColumn("partitionID", spark_partition_id())
flightDataDF2015_rp.sort("DEST_COUNTRY_NAME").show(5000)

# COMMAND ----------

flightDataDF2015_rp.sort("partitionID").show(5000)

# COMMAND ----------

flightDataDF2015_rp.rdd.getNumPartitions()

# COMMAND ----------

# Notice that one column is aligned to a single partition. It will avoid shuffling issues
flightDataDF2015_rp.groupBy("DEST_COUNTRY_NAME")\
.agg(concat_ws(", ", collect_set(flightDataDF2015_rp.partitionID))).display(5000)

#flightDataDF2015_rp.sort("partitionID").show(20000)

# COMMAND ----------

# Notice that one column is aligned to a single partition. It will avoid shuffling issues
flightDataDF2015_rp.groupBy("partitionID")\
.agg(concat_ws(", ", collect_set(flightDataDF2015_rp.partitionID))).display(5000)

#flightDataDF2015_rp.sort("partitionID").show(20000)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Execution plan comparision between SQL Way and Datafram Way

# COMMAND ----------

flightDataDF2015.createOrReplaceTempView("flight_data_2015")
sqlWay = spark\
.sql("""
select dest_country_name, count(1)
from flight_data_2015
group by dest_country_name
""")

# COMMAND ----------

dataFrameWay = flightDataDF2015\
.groupBy("dest_country_name")\
.count()

# COMMAND ----------

# The physical execution plans are almost ame either way
sqlWay.explain()
dataFrameWay.explain()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Grouping on regular dataframe

# COMMAND ----------

flightDataDF2015_groupBy=flightDataDF2015\
.groupBy("DEST_COUNTRY_NAME")\
.sum("count")\
.withColumnRenamed("sum(count)", "destination_total")

# COMMAND ----------

# Only 3 partitions are created and group by will result in shuffling
flightDataDF2015.rdd.getNumPartitions()

# COMMAND ----------

# Let's save the results. This will initiate Action and also to the data shuffling
dbutils.fs.rm("/mnt/data/data/gprby_DEST_COUNTRY_NAME",True)
#Here data shuffleing will happen which is an expensive operation
flightDataDF2015_groupBy.write.mode('overwrite').format("csv").option("header", "true").save("dbfs:/mnt/data/data/gprby_DEST_COUNTRY_NAME")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/data/data/gprby_DEST_COUNTRY_NAME

# COMMAND ----------

# MAGIC %md
# MAGIC ## Grouping on repartitioned dataframe

# COMMAND ----------

# No/Minimal shuffling will happen
flightDataDF2015_rp_groupBy=flightDataDF2015_rp\
.groupBy("dest_country_name")\
.sum("count")\
.withColumnRenamed("sum(count)", "destination_total")

# COMMAND ----------

dbutils.fs.rm("/mnt/data/data/gprby2_DEST_COUNTRY_NAME",True)

# COMMAND ----------

# Here the RDD Action will trigger and notice that multiple files will be saved, one file each partition
flightDataDF2015_rp_groupBy.write.mode('overwrite').format("csv").option("header", "true").save("dbfs:/mnt/data/data/gprby2_DEST_COUNTRY_NAME")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/data/data/gprby2_DEST_COUNTRY_NAME

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dealing with Manual / Static Schema

# COMMAND ----------

staticSchema = flightDataDF2015.schema

# COMMAND ----------

print(staticSchema)

# COMMAND ----------

flightDataDF2015 = spark\
.read\
.schema(staticSchema)\
.option("header", "true")\
.csv(flightData2015)

# COMMAND ----------

flightDataDF2015.display()

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, StringType, LongType

# COMMAND ----------

myManualSchema = StructType([\
                            StructField("DEST_COUNTRY_NAME", StringType(), nullable=False),\
                            StructField("ORIGIN_COUNTRY_NAME", StringType(), nullable=False),\
                            StructField("count", StringType(), nullable=False, metadata={"hello":"world"})\
                            ])
df1 = spark.read.format("csv").schema(myManualSchema)\
.load(flightData2015)


# COMMAND ----------

df1.display()

# COMMAND ----------

flightDataDF2015.rdd.getNumPartitions()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Can specify to create multiple files, one for each value in the columns

# COMMAND ----------

# Slow Performance as all data is to be reshuffled
dbutils.fs.rm("dbfs:/mnt/data/data/P_By_DEST_COUNTRY_NAME", True)
flightDataDF2015.write.partitionBy("DEST_COUNTRY_NAME").format("csv").save("dbfs:/mnt/data/data/P_By_DEST_COUNTRY_NAME")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/data/data/P_By_DEST_COUNTRY_NAME

# COMMAND ----------

# Fast Performance as all data is spread across partitions with each executer
dbutils.fs.rm("dbfs:/mnt/data/data/P_By_DEST_COUNTRY_NAME_2", True)
flightDataDF2015_rp.write.partitionBy("DEST_COUNTRY_NAME").format("csv").save("dbfs:/mnt/data/data/P_By_DEST_COUNTRY_NAME_2")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/data/data/P_By_DEST_COUNTRY_NAME_2

# COMMAND ----------

# Multiple executers will load the data paralally
df1 = spark.read.format("csv").schema(myManualSchema)\
.load("dbfs:/mnt/data/data/P_By_DEST_COUNTRY_NAME_2")

# COMMAND ----------

# Multiple executers will load the data paralally
df1 = spark.read.format("csv").schema(myManualSchema)\
.load("dbfs:/mnt/data/data/P_By_DEST_COUNTRY_NAME_2")

# COMMAND ----------

df1.createOrReplaceTempView("flight_data_2015")
sqlWay = spark\
.sql("""
select *
from flight_data_2015
where dest_country_name='United States'
""")

# COMMAND ----------

sqlWay.show(10000000)

# COMMAND ----------

# Notice the number of partitions created
df1.rdd.getNumPartitions()

# COMMAND ----------

df1.display()

# COMMAND ----------

