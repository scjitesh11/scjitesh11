# Databricks notebook source
from pyspark.sql.functions import spark_partition_id
data1 = [{'Name':'Jhon','ID':21.528,'Add':'USA'},{'Name':'Joe','ID':3.69,'Add':'USA'},{'Name':'Tina','ID':2.48,'Add':'IND'},{'Name':'Jhon','ID':22.22, 'Add':'USA'},{'Name':'Joe','ID':5.33,'Add':'INA'}]
a = sc.parallelize(data1)
b = spark.createDataFrame(a)
b=b.withColumn("partitionID", spark_partition_id())
b.show()

# COMMAND ----------

data2 = [{'Name':'Atin','ID':21.528,'Add':'India'},{'Name':'Joe','ID':3.69,'Add':'USeA'},{'Name':'Tina','ID':2.48,'Add':'IND'},{'Name':'Jhon','ID':22.22, 'Add':'USdA'},{'Name':'Joe','ID':5.33,'Add':'rsa'}]
c = sc.parallelize(data2)
d = spark.createDataFrame(c)
d=d.withColumn("partitionID", spark_partition_id())
d.show()

# COMMAND ----------

f = d.join(b,d.Add == b.Add)
f.explain(True)

# COMMAND ----------

f.show()

# COMMAND ----------

from pyspark.sql.functions import broadcast
f = d.join(broadcast(b),d.Add == b.Add)
f.explain(True)

# COMMAND ----------

f.show()

# COMMAND ----------

f.rdd.getNumPartitions()

# COMMAND ----------

peopleDF = (
  ("andrea", "medellin"),
  ("rodolfo", "medellin"),
  ("abdul", "bangalore")
)

peopleDF_a = sc.parallelize(peopleDF)
peopleDF_b = spark.createDataFrame(peopleDF_a, ["first_name", "city"])

peopleDF_b.show()

# COMMAND ----------

citiesDF = (
  ("medellin", "colombia", 2.5),
  ("bangalore", "india", 12.3)
)




citiesDF_a = sc.parallelize(citiesDF)
citiesDF_b = spark.createDataFrame(citiesDF_a, ("city", "country", "population"))

citiesDF_b.show()

# COMMAND ----------

peopleDF_b_j = peopleDF_b.join(
  broadcast(citiesDF_b),
  peopleDF_b.city == citiesDF_b.city
)

peopleDF_b_j.explain(True)

# COMMAND ----------

peopleDF_b_j = peopleDF_b.join(
  citiesDF_b,
  peopleDF_b.city == citiesDF_b.city
)

peopleDF_b_j.explain(True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Notice how the parsed, analyzed, and optimized logical plans all contain ResolvedHint isBroadcastable=true because the broadcast() function was used. This hint isn’t included when the broadcast() function isn’t used.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Automatic Detection

# COMMAND ----------

# MAGIC %md
# MAGIC - In many cases, Spark can automatically detect whether to use a broadcast join or not, depending on the size of the data. If Spark can detect that one of the joined DataFrames is small (10 MB by default), Spark will automatically broadcast it for us. The code below:

# COMMAND ----------

bigTable = spark.range(1, 100000000)
smallTable = spark.range(1, 10000) # size estimated by Spark - auto-broadcast
joinedNumbers = smallTable.join(bigTable, "id")
joinedNumbers.explain(True)

# COMMAND ----------

# MAGIC %md
# MAGIC - However, in the previous case, Spark did not detect that the small table could be broadcast. 
# MAGIC - The reason is that Spark will not determine the size of a local collection because it might be big, and evaluating its size may be an O(N) operation, which can defeat the purpose before any computation is made.

# COMMAND ----------

# MAGIC %md
# MAGIC - Spark will perform auto-detection when
# MAGIC     - it constructs a DataFrame from scratch, e.g. spark.range
# MAGIC     - it reads from files with schema and/or size information, e.g. Parquet

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuring Broadcast Join Detection

# COMMAND ----------

# MAGIC %md
# MAGIC - The threshold for automatic broadcast join detection can be tuned or disabled.
# MAGIC - The configuration is spark.sql.autoBroadcastJoinThreshold, and the value is taken in bytes. If you want to configure it to another number, we can set it in the SparkSession:

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 104857600)

# COMMAND ----------

# MAGIC %md
# MAGIC - or deactivate it altogether by setting the value to -1.

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1) 

# COMMAND ----------

