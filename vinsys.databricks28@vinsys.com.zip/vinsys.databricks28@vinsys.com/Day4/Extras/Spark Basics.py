# Databricks notebook source
# MAGIC %md
# MAGIC ### Set data Path

# COMMAND ----------

flightData2015 = '/mnt/data/data/flight-data/csv/2015-summary.csv'
retailDataDay = '/mnt/data/data/retail-data/by-day/'
retailDataDaySmall = '/mnt/data/data/retail-data/by-day/2010-12-02.csv'

# COMMAND ----------

# MAGIC %md
# MAGIC ## What is Apache Spark?

# COMMAND ----------

# MAGIC %md
# MAGIC -  Unified computing engine for parallel data processing distributed across clusters (machine nodes)   
# MAGIC <br>
# MAGIC     -  Structured APIs:
# MAGIC         -  Datasets
# MAGIC         -  DataFrames
# MAGIC         -  SQL   
# MAGIC         <br>
# MAGIC     -  Unstructured APIs:
# MAGIC         -  RDDs   
# MAGIC         <br>
# MAGIC     -  Libraries:
# MAGIC         -  Structured Streaming
# MAGIC         -  Machine Learning
# MAGIC         -  Graph   
# MAGIC         <br>
# MAGIC     -  Language APIs:
# MAGIC         -  Scala
# MAGIC         -  Java
# MAGIC         -  Python
# MAGIC         -  SQL
# MAGIC         -  R

# COMMAND ----------

# MAGIC %md
# MAGIC ## Introduction to Spark

# COMMAND ----------

# MAGIC %md
# MAGIC -  Spark Applications:
# MAGIC     -  Driver (heart of Spark Application during application's lifecycle):
# MAGIC         -  maintains information about Spark Application
# MAGIC         -  responds to user's program / input
# MAGIC         -  distributes and schedules work across executors   
# MAGIC         <br>
# MAGIC     -  Executors:
# MAGIC         -  executes work (code) assigned by driver
# MAGIC         -  reports state of work execution back to driver node   
# MAGIC         <br>
# MAGIC     -  SparkSession:
# MAGIC         -  entry point that manages Spark Application via driver process   
# MAGIC         <br>
# MAGIC     -  DataFrames:
# MAGIC         -  represents a table of data with rows and columns
# MAGIC         -  compiled in a schema that defines the column labels and data types   
# MAGIC         <br>
# MAGIC     -  Partitions:
# MAGIC         -  chunks of data distributed across cluster for parallel execution
# MAGIC         -  in addition, a collection of rows sitting on one physical machine in cluster
# MAGIC         -  parallelism = partitions = executors (x: 1 partition / 1,000 executors = parallelism of 1; 1,000 paritions / 1 executors = parallelism of 1)   
# MAGIC         <br>
# MAGIC     -  Lazy Evaluation:
# MAGIC         -  bundles plan of transformations on source data into DAG then triggers DAG on action
# MAGIC         -  molds a logical plan into a pysical plan that will run across cluster   
# MAGIC         <br>
# MAGIC     -  Transformations:
# MAGIC          -  data manipulations and modifications   
# MAGIC             <br>
# MAGIC              -  Narrow Transformations (1 to 1):
# MAGIC                  -  each input partition will contribute to only one output partition
# MAGIC                  -  no dependencies => 1 parent w/ 1 child
# MAGIC                  -  ex: filter, maps   
# MAGIC                 <br>
# MAGIC              -  Wide Transformations (1 to N):
# MAGIC                   -  "aka" shuffle
# MAGIC                   -  many dependencies => 1 parent w/ many children
# MAGIC                   -  each input partition will contribute to many output partitions across the cluster
# MAGIC                   -  when a shuffle occurs Spark writes the results to disk ex: spark.sql.shuffle.partitions
# MAGIC                   -  ex: aggregations, joins, groupings   
# MAGIC        <br>           
# MAGIC     -  Actions:
# MAGIC         -  triggers the series of transformations into a spark job
# MAGIC             -  types:
# MAGIC                 -  view data in the console
# MAGIC                 -  collect data
# MAGIC                 -  write to output data sources

# COMMAND ----------

# MAGIC %md
# MAGIC    -  Spark Job (represents set of transformations triggered by an individual action)
# MAGIC    -  Schema Inference (have Spark best guess the schema of data) ***triggers Spark Job when scanning through data***
# MAGIC    -  Spark-Submit (launches application code to a cluster)
# MAGIC    -  Catalyst (planning and processing of work engine)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Note: Spark contains separate Python and R processes hence when using Spark from Python or R language API the Python or R code is transaled into code that Spark can run on the executor JVMs

# COMMAND ----------

# MAGIC %md
# MAGIC ### Practicals

# COMMAND ----------

flightData2015

# COMMAND ----------

#cat '../data/flight-data/csv/2015-summary.csv'

# COMMAND ----------

flightDataDF2015 = spark\
.read\
.option("inferSchema", "true")\
.option("header", "true")\
.csv(flightData2015)

# COMMAND ----------

flightDataDF2015.printSchema()

# COMMAND ----------

flightDataDF2015.rdd.getNumPartitions()

# COMMAND ----------

flightDataDF2015.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC -  **Explain Plan**:
# MAGIC     -  displays DFs lineage

# COMMAND ----------

flightDataDF2015_tmp=flightDataDF2015.sort("count")

# COMMAND ----------

flightDataDF2015_tmp.show()

# COMMAND ----------

# MAGIC %md
# MAGIC -  **SPARK.SQL.SHUFFLE.PARTITIONS**:
# MAGIC     -  by default, there are 200 shuffle partitions

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "5")

# COMMAND ----------

flightDataDF2015.sort("count", ascending=False).show()

# COMMAND ----------

flightDataDF2015.createOrReplaceTempView("flight_data_2015")

# COMMAND ----------

sqlWay = spark\
.sql("""
select dest_country_name, count(1)
from flight_data_2015
group by dest_country_name
""")

# COMMAND ----------

dataFrameWay = flightDataDF2015\
.groupBy("dest_country_name")\
.count()

# COMMAND ----------

dataFrameWay.explain(True)

# COMMAND ----------

dataFrameWay.show()

# COMMAND ----------

sqlWay.show()

# COMMAND ----------

dataFrameWay.show()

# COMMAND ----------

print(sqlWay.explain(True))

print(dataFrameWay.explain(True))

# COMMAND ----------

from pyspark.sql.functions import desc

# COMMAND ----------

flightDataDF2015\
.groupBy("dest_country_name")\
.sum("count")\
.withColumnRenamed("sum(count)", "destination_total")\
.sort(desc("destination_total"))\
.limit(5).explain()

# COMMAND ----------

flightDataDF2015\
.groupBy("dest_country_name")\
.sum("count")\
.withColumnRenamed("sum(count)", "destination_total")\
.sort(desc("destination_total"))\
.limit(3)\
.show()

# COMMAND ----------

flightDataDF2015.schema

# COMMAND ----------

print(retailDataDaySmall)

# COMMAND ----------

staticDataFrame = spark\
.read\
.format("csv")\
.option("header", "true")\
.option("inferSchema", "true")\
.load(retailDataDaySmall)

# COMMAND ----------

staticDataFrame.createOrReplaceTempView("retail_data")
staticSchema = staticDataFrame.schema

# COMMAND ----------

staticDataFrame.show()

# COMMAND ----------

