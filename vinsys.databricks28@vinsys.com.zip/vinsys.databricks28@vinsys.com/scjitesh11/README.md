- 👋 Hi, I’m Satish Choudhury
- 👀 I’m interested in data analytics...
- 🌱 I’m currently learning data analysis...
- 💞️ I’m looking to collaborate on data analysis and data science ...
- 📫 Can reach me at... scjitesh11@gmail.com

<!---
scjitesh11/scjitesh11 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
